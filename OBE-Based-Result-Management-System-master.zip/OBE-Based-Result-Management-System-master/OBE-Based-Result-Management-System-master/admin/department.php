<?php include("db.php");?>

<?php
  $errors = array();
  function test_input($data){
    $data = trim($data); 
    $data = stripslashes($data); 
    $data = htmlspecialchars($data);  
    return $data;
  } 

  if(isset($_POST['add'])){

    $department = mysqli_real_escape_string($connection, $_POST['new_dept']);
    $department = test_input($department);

    if(empty($_POST['new_dept'])){  
         $errors['new_dept'] = "Please Enter department name";
         echo '<script type="text/javascript">'; 
         echo 'setTimeout(function () { swal("'.$errors['new_dept'].'");';
         echo '}, 300);</script>';
    }

    if(count($errors) == 0){
        // Check if department exists
        $sql = "SELECT * FROM dept";
        if($result = mysqli_query($connection, $sql)){
            if(mysqli_num_rows($result) > 0){
                while($row = mysqli_fetch_array($result)){
                    if(isset($row['dept']) && $row['dept'] == $department){
                        echo '<script type="text/javascript">'; 
                        echo 'setTimeout(function () { swal("Department already exist !!");';
                        echo '}, 600);</script>';
                    }
                }
            }
        }

        // Insert new department
        $sql = "INSERT INTO dept(dept) VALUES('$department')";

        if($result = mysqli_query($connection, $sql)){
            echo '<script type="text/javascript">'; 
            echo 'setTimeout(function () { swal("Successfully Inserted");';
            echo '}, 600);</script>';
        }
    }
  }

  if(isset($_POST['delete_row'])){
        $row_id = $_POST['delete_row'];
        $sql = "DELETE FROM dept WHERE dept_id='$row_id'";

        if(mysqli_query($connection, $sql)){
            echo '<script type="text/javascript">'; 
            echo 'setTimeout(function () { swal("Successfully Deleted !!");';
            echo '}, 600);</script>';
        }
  }

  if(isset($_POST['edit_row'])){
      $row_id = $_POST['edit_row'];
      header('Location: edit_dept.php?value='.$row_id);
  } 
?>

<!DOCTYPE html>
<html>
<head>
  <title>Department Management - UITS</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="../css/style_2.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="../css/bootstrap.min.css">
  <script src="../js/sweetalert.min.js"></script>
  <script src="../js/jquery-3.2.1.min.js"></script>
  <script src="../js/bootstrap.min.js"></script>
  <style>
      /* ===== Dark (black) theme ===== */
      html, body {
          background-color: #000000 !important;
          color: #e5e5e5;
      }

      /* Sidebar */
      #tbl1 {
          background: #0d0d0d !important;
          box-shadow: 2px 0 10px rgba(0,0,0,0.6) !important;
          border-right: 1px solid #222;
      }
      #tbl1 a {
          color: #cfcfcf !important;
          font-weight: 600;
          text-decoration: none;
          display: block;
          padding: 5px 0;
          transition: 0.2s;
      }
      #tbl1 a:hover {
          color: #4da3ff !important;
          padding-left: 5px;
      }

      /* Main panel */
      #main-panel {
          flex-grow: 1;
          padding: 25px;
          background-color: #0d0d0d;
          margin-left: 20px;
          border-radius: 8px;
          border: 1px solid #222;
          box-shadow: 0 2px 8px rgba(0,0,0,0.6);
      }
      #main-panel h3 {
          margin-top: 0;
          color: #ffffff;
          border-bottom: 2px solid #2a5298;
          padding-bottom: 10px;
      }

      /* Table */
      #tbl2.table-bordered,
      #tbl2.table-bordered > thead > tr > th,
      #tbl2.table-bordered > tbody > tr > td {
          border-color: #333 !important;
      }
      #tbl2 > thead > tr > th {
          background-color: #1a1a1a !important;
          color: #ffffff !important;
      }
      #tbl2 > tbody > tr > td {
          background-color: #111111 !important;
          color: #e5e5e5 !important;
      }
      #tbl2.table-striped > tbody > tr:nth-of-type(odd) > td {
          background-color: #161616 !important;
      }
      #tbl2 > tbody > tr:hover > td {
          background-color: #1f1f1f !important;
      }
      #tbl2 strong {
          color: #ffffff;
      }

      /* Inputs */
      #tbl2 .form-control {
          background-color: #1a1a1a;
          color: #ffffff;
          border: 1px solid #333;
          box-shadow: none;
      }
      #tbl2 .form-control::placeholder {
          color: #888888;
      }
      #tbl2 .form-control:focus {
          border-color: #2a5298;
          background-color: #202020;
      }
  </style>
</head>
<body>
   <div id="function">
     <div>
      <nav class="navbar navbar-default" id="nb" style="background: #0d0d0d; border: none; border-bottom: 1px solid #222; border-radius: 0;">
        <div class="container-fluid">
          <div class="navbar-header">
            <a class="navbar-brand" href="#" style="color: #ffffff !important; font-weight: bold; font-size: 20px;"><i class="fa fa-tachometer"></i> UITS Admin Dashboard</a>
          </div>
        </div>
      </nav>
      <div style="width:95%; margin:0px auto; display: flex;" id="nb2">
       
       <!-- UITS Sidebar -->
       <table id="tbl1" width="16%" height="565px" style="flex-shrink: 0; padding: 15px;">
        <tr><td valign="top"><br>
          <a href="#" class="glyphicon glyphicon-user" style="font-weight: bold; color: #4da3ff !important;"> UITS</a><br><br>
          <a href="admin_dashboard.php"><i class="fa fa-home"></i> Dashboard</a><br><br>
          <a href="department.php" style="background: #2a5298; color: #ffffff !important; padding: 8px 12px; border-radius: 4px;"><i class="fa fa-building-o"></i> Department</a><br><br>
          <a href="course.php"><i class="fa fa-book"></i> Course</a><br><br>
          <a href="offered_course.php"><i class="fa fa-bookmark-o"></i> Offer Course</a><br><br>
          <a href="assign_course.php"><i class="fa fa-tasks"></i> Assign Course</a><br><br>
          <a href="component.php"><i class="fa fa-cubes"></i> Component</a><br><br>
          <a href="history.php"><i class="fa fa-graduation-cap"></i> Student PO</a><br><br>
          <a href="st_enrollment.php"><i class="fa fa-users"></i> Student Enrollment</a><br><br><br>
          <a href="../logout.php" class="glyphicon glyphicon-log-out" style="color: #ff6b6b !important;"> Logout</a>
          </td>
        </tr>
      </table>  

      <!-- Main Department Section -->
      <div id="main-panel">
        <h3>Department Management</h3>
        <br>
        <form method="POST" action="">
          <div class="table-responsive" style="border: none;">
            <table id="tbl2" class="table table-bordered table-striped" width="100%">
              <thead>
                <tr>
                    <th>Department Name</th>
                    <th style="width: 15%; text-align: center;">Action</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td><input type="text" name="new_dept" class="form-control" placeholder="Enter Department Name"> </td>
                  <td style="text-align: center;"><button type="submit" name="add" class="btn btn-success"><i class="fa fa-plus-circle"></i> Add</button></td>
                </tr>

               <?php 
                $query_2 = "SELECT * FROM dept";
                if($select = mysqli_query($connection, $query_2)){
                    if(mysqli_num_rows($select) > 0){
                        while ($row = mysqli_fetch_array($select)){
                            echo "<tr>";
                            echo "<td><strong>".$row['dept']."</strong></td>";
               ?>
                  <td style="text-align: center;">
                    <button type="submit" name="edit_row" class="btn btn-warning btn-sm" value="<?php echo $row['dept_id']; ?>"><i class="fa fa-edit"></i></button>
                    <button type="submit" name="delete_row" class="btn btn-danger btn-sm" value="<?php echo $row['dept_id']; ?>" onclick="return confirm('Are you sure to delete?')"><i class="fa fa-trash"></i></button>
                  </td>
               <?php
                            echo "</tr>";  
                        }
                    }
                }
               ?>
              </tbody>
            </table>
          </div>
        </form>
      </div>

    </div>
  </div>
</body>
</html>