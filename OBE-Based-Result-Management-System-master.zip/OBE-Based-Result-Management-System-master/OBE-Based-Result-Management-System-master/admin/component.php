<?php include("db.php");

  $errors = array();
  function test_input($data){
    $data = trim($data); 
    $data = stripslashes($data); 
    $data = htmlspecialchars($data);  
    return $data;
  } 

  if(isset($_POST['add'])){
    $component = mysqli_real_escape_string($connection, $_POST['new_comp']);
    $component = test_input($component);
  
    if(empty($_POST['new_comp'])){  
         $errors['new_comp'] = "Please Enter component name";
         echo '<script type="text/javascript">'; 
         echo 'setTimeout(function () { swal("'.$errors['new_comp'].'");';
         echo '},300);</script>';
    }

    if(count($errors) == 0){
        $exists = false;
        $sql = "SELECT * FROM comp";
        if($result = mysqli_query($connection, $sql)){
            if(mysqli_num_rows($result) > 0){
                while($row = mysqli_fetch_array($result)){
                    if(strcasecmp($row['component'], $component) == 0){
                        $exists = true;
                        break;
                    }
                }
            }
        }

        if($exists){
            echo '<script type="text/javascript">'; 
            echo 'setTimeout(function () { swal("Component already exist !!");';
            echo '},300);</script>';
        } else {
            $sql = "INSERT INTO comp(component) VALUES('$component')";
            if($result = mysqli_query($connection, $sql)){
                echo '<script type="text/javascript">'; 
                echo 'setTimeout(function () { swal("Successfully Inserted");';
                echo '},300);</script>';
            }
        }
    }
  }

  if(isset($_POST['edit_row'])){
      $row_id = $_POST['edit_row'];
      header('Location:edit_comp.php?value='.$row_id);
      exit();
  } 
?>

<!DOCTYPE html>
<html>
<head>
  <title>Component Management - UITS</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="../css/style_2.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="../css/bootstrap.min.css">
  <script src="../js/sweetalert.min.js"></script>
  <script src="../js/jquery-3.2.1.min.js"></script>
  <script src="../js/bootstrap.min.js"></script>
  <style>
      /* ===== Dark colorful theme ===== */
      html, body {
          background: #0b0f1a !important;
          background-image:
              radial-gradient(circle at 10% 0%, rgba(124,58,237,0.25) 0, transparent 40%),
              radial-gradient(circle at 90% 100%, rgba(6,182,212,0.22) 0, transparent 40%) !important;
          background-attachment: fixed !important;
          color: #e5e7eb;
          min-height: 100vh;
      }

      /* Navbar */
      #nb {
          background: linear-gradient(90deg, #7c3aed 0%, #2563eb 50%, #06b6d4 100%) !important;
          border: none !important;
          border-radius: 0 !important;
          box-shadow: 0 4px 20px rgba(37,99,235,0.45);
      }
      #nb .navbar-brand {
          color: #ffffff !important;
          font-weight: 700;
          font-size: 20px;
          text-shadow: 0 1px 4px rgba(0,0,0,0.35);
      }

      /* Sidebar */
      #tbl1 {
          background: #121829 !important;
          border: 1px solid #243049;
          border-radius: 12px;
          box-shadow: 0 6px 24px rgba(0,0,0,0.5);
          padding: 15px;
      }
      #tbl1 a {
          color: #cbd5e1 !important;
          font-weight: 600;
          text-decoration: none;
          display: block;
          padding: 8px 12px;
          border-radius: 8px;
          transition: all 0.25s;
      }
      #tbl1 a:hover {
          background: rgba(99,102,241,0.18);
          color: #ffffff !important;
          padding-left: 18px;
      }
      #tbl1 a.active-link {
          background: linear-gradient(90deg, #7c3aed, #2563eb) !important;
          color: #ffffff !important;
          box-shadow: 0 4px 14px rgba(124,58,237,0.5);
      }
      #tbl1 a.logout-link { color: #fb7185 !important; }
      #tbl1 a.logout-link:hover { background: rgba(251,113,133,0.15); }
      #tbl1 a.brand-link { color: #22d3ee !important; font-weight: 700; }

      /* Colorful sidebar icons */
      #tbl1 .c1 { color: #38bdf8; }
      #tbl1 .c2 { color: #f472b6; }
      #tbl1 .c3 { color: #fbbf24; }
      #tbl1 .c4 { color: #34d399; }
      #tbl1 .c5 { color: #a78bfa; }
      #tbl1 .c6 { color: #fb923c; }
      #tbl1 .c7 { color: #f87171; }
      #tbl1 .c8 { color: #2dd4bf; }
      #tbl1 a.active-link i { color: #ffffff; }

      /* Main card */
      #main-card {
          flex-grow: 1;
          padding: 25px;
          margin-left: 20px;
          background: #121829;
          border: 1px solid #243049;
          border-radius: 12px;
          box-shadow: 0 6px 24px rgba(0,0,0,0.5);
      }
      #main-card h3 {
          margin-top: 0;
          padding-bottom: 12px;
          font-weight: 700;
          color: #ffffff;
          border-bottom: 3px solid transparent;
          border-image: linear-gradient(90deg, #a78bfa, #38bdf8, #34d399) 1;
      }
      #main-card h3 i { color: #fbbf24; margin-right: 6px; }

      /* Table */
      #tbl2 {
          background: transparent !important;
          border: 1px solid #2b3a57 !important;
          color: #e5e7eb;
      }
      #tbl2 > thead > tr > th {
          background: linear-gradient(90deg, #7c3aed, #2563eb, #06b6d4) !important;
          color: #ffffff !important;
          border: none !important;
          font-size: 15px;
          letter-spacing: 0.4px;
          padding: 12px;
      }
      #tbl2 > tbody > tr > td {
          border-color: #2b3a57 !important;
          vertical-align: middle !important;
          color: #f1f5f9;
      }
      #tbl2.table-striped > tbody > tr:nth-of-type(odd) > td { background: #161e33 !important; }
      #tbl2.table-striped > tbody > tr:nth-of-type(even) > td { background: #1b2540 !important; }
      #tbl2 > tbody > tr:hover > td { background: #25325a !important; }
      #tbl2 strong { color: #67e8f9; font-weight: 600; }

      /* Input */
      #tbl2 .form-control {
          background: #0b1222 !important;
          color: #ffffff !important;
          border: 1px solid #3b4d7a !important;
          border-radius: 8px;
          height: 38px;
          box-shadow: none;
      }
      #tbl2 .form-control::placeholder { color: #8ea0c4; }
      #tbl2 .form-control:focus {
          border-color: #38bdf8 !important;
          box-shadow: 0 0 0 3px rgba(56,189,248,0.3) !important;
      }

      /* Buttons */
      .btn-success {
          background: linear-gradient(135deg, #10b981, #06b6d4) !important;
          border: none !important;
          color: #fff !important;
          font-weight: 600;
          border-radius: 8px;
          box-shadow: 0 4px 12px rgba(16,185,129,0.4);
      }
      .btn-success:hover { filter: brightness(1.12); transform: translateY(-1px); }
      .btn-warning {
          background: linear-gradient(135deg, #f59e0b, #f43f5e) !important;
          border: none !important;
          color: #fff !important;
          border-radius: 8px;
          box-shadow: 0 4px 12px rgba(245,158,11,0.4);
      }
      .btn-warning:hover { filter: brightness(1.12); transform: translateY(-1px); }

      .text-center { color: #94a3b8; }
  </style>
</head>
<body>
   <div id="function">
	   <div>
			<nav class="navbar navbar-default" id="nb">
			  <div class="container-fluid">
			    <div class="navbar-header">
			      <a class="navbar-brand" href="#"><i class="fa fa-tachometer"></i> UITS Admin Dashboard</a>
			    </div>
			  </div>
		  </nav>

      <div style="width:95%; margin:0px auto; display: flex;" id="nb2">
       
       <!-- UITS Sidebar -->
       <table id="tbl1" width="16%" height="565px" style="flex-shrink: 0;">
        <tr><td valign="top"><br>
          <a href="#" class="glyphicon glyphicon-user brand-link"> UITS</a><br><br>
          <a href="admin_dashboard.php"><i class="fa fa-home c1"></i> Dashboard</a><br><br>
          <a href="department.php"><i class="fa fa-building-o c2"></i> Department</a><br><br>
          <a href="course.php"><i class="fa fa-book c3"></i> Course</a><br><br>
          <a href="offered_course.php"><i class="fa fa-bookmark-o c4"></i> Offer Course</a><br><br>
          <a href="assign_course.php"><i class="fa fa-tasks c5"></i> Assign Course</a><br><br>
          <a href="component.php" class="active-link"><i class="fa fa-cubes"></i> Component</a><br><br>
          <a href="history.php"><i class="fa fa-graduation-cap c6"></i> Student PO</a><br><br>
		  <a href="st_enrollment.php"><i class="fa fa-users c8"></i> Student Enrollment</a><br><br><br>
          <a href="../logout.php" class="glyphicon glyphicon-log-out logout-link"> Logout</a>
          </td>
        </tr>
      </table>  

	  <!-- Main Component Content -->
	  <div id="main-card">
	    <h3><i class="fa fa-cubes"></i> Component Management</h3>
        <br>

		<form method="POST" action="">
          <div class="table-responsive" style="border: none;">
            <table id="tbl2" class="table table-bordered table-striped" width="100%">
              <thead>
                <tr>
                    <th>Component Name</th>
                    <th style="width: 15%; text-align: center;">Action</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td><input type="text" name="new_comp" class="form-control" placeholder="Enter Component Name" required></td>
                  <td style="text-align: center;">
                      <button type="submit" name="add" class="btn btn-success"><i class="fa fa-plus-circle"></i> Add Component</button>
                  </td>
                </tr>

                <?php 
                    $query_2 = "SELECT * FROM comp";
                    if($select = mysqli_query($connection, $query_2)){
                        if(mysqli_num_rows($select) > 0){
                            while ($row = mysqli_fetch_array($select)){
                                echo "<tr>";
                                echo "<td><strong>".$row['component']."</strong></td>";
                        ?>
                  <td style="text-align: center;">
                      <button type="submit" name="edit_row" class="btn btn-warning btn-sm" value="<?php echo $row['comp_id']; ?>"><i class="fa fa-edit"></i></button>
                  </td>
                <?php
                                echo "</tr>";  
                            }
                        } else {
                            echo "<tr><td colspan='2' class='text-center'>No components found.</td></tr>";
                        }
                    }
                ?>
              </tbody>
            </table>
          </div>
        </form>
	   </div>

	</div>
  </div>
</body>
</html>