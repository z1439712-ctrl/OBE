<?php 
include("db.php");
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$username = isset($_SESSION['username']) ? $_SESSION['username'] : 'Admin';

/* ============================================================
   OBE CONFIGURATION (standard thresholds & mapping)
   ============================================================ */
const TARGET_ATTAINMENT = 60;   // % -> CO/PO "Attained" if >= 60
const PARTIAL_LIMIT     = 40;   // % -> 40-59 = Partially, <40 = Not Attained
const RISK_LIMIT        = 70;   // % -> overall attainment below this = Risk badge
const CRITICAL_LIMIT    = 50;   // % -> below this = "At Risk"

// Grade -> percentage (BD private university style scale)
$grade_scale = [
    'A+' => 90, 'A' => 85, 'A-' => 80,
    'B+' => 75, 'B' => 70, 'B-' => 65,
    'C+' => 60, 'C' => 55, 'D' => 50, 'F' => 30
];

// CO -> PO mapping weights (CO1 & CO2 map to PO1, PO2, PO3)
// Eta change korle mapping change hobe. Future e DB table theke anar jonno ready.
$co_po_map = [
    'CO1' => ['PO1' => 60, 'PO2' => 40],
    'CO2' => ['PO2' => 50, 'PO3' => 50],
];
$po_list = ['PO1', 'PO2', 'PO3'];

function status_of($v) {
    if ($v >= TARGET_ATTAINMENT) return 'Attained';
    if ($v >= PARTIAL_LIMIT)     return 'Partial';
    return 'Not Attained';
}
function status_color($s) {
    if ($s == 'Attained') return '#2ecc71';
    if ($s == 'Partial')  return '#e67e22';
    return '#e74c3c';
}

/* ---------- Helper: average PO of a grade (used for batch summary) ---------- */
function calc_po_avg($grade) {
    global $grade_scale, $co_po_map, $po_list;
    $g = strtoupper(trim($grade));
    $base = isset($grade_scale[$g]) ? $grade_scale[$g] : 0;
    $co = [
        'CO1' => min(100, max(0, $base + 3)),
        'CO2' => min(100, max(0, $base - 5)),
    ];
    $po = [];
    foreach($po_list as $p){
        $num = 0; $den = 0;
        foreach($co_po_map as $c => $targets){
            if(isset($targets[$p])){ $num += $co[$c] * $targets[$p]; $den += $targets[$p]; }
        }
        $po[$p] = $den > 0 ? $num / $den : 0;
    }
    return round(array_sum($po) / count($po), 1);
}

/* ============================================================
   NEW: Auto-create helper tables (Audit Log + CQI Remarks)
   ============================================================ */
mysqli_query($connection, "CREATE TABLE IF NOT EXISTS obe_audit_log (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100),
    action VARCHAR(50),
    s_id VARCHAR(50),
    details VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)");
mysqli_query($connection, "CREATE TABLE IF NOT EXISTS cqi_remarks (
    id INT AUTO_INCREMENT PRIMARY KEY,
    s_id VARCHAR(50),
    item VARCHAR(20),
    remark TEXT,
    updated_by VARCHAR(100),
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_student_item (s_id, item)
)");

function audit_log($connection, $user, $action, $sid, $details) {
    $user    = mysqli_real_escape_string($connection, $user);
    $action  = mysqli_real_escape_string($connection, $action);
    $sid     = mysqli_real_escape_string($connection, $sid);
    $details = mysqli_real_escape_string($connection, $details);
    mysqli_query($connection, "INSERT INTO obe_audit_log (username, action, s_id, details) VALUES ('$user','$action','$sid','$details')");
}

/* ============================================================
   NEW: Advanced filter values (Semester / Year / Section)
   ============================================================ */
$f_sem  = isset($_POST['f_semester']) ? trim($_POST['f_semester']) : '';
$f_year = isset($_POST['f_year'])     ? trim($_POST['f_year'])     : '';
$f_sec  = isset($_POST['f_section'])  ? trim($_POST['f_section'])  : '';
$filter_sql = '';
if($f_sem  !== '') $filter_sql .= " AND semester='".mysqli_real_escape_string($connection, $f_sem)."'";
if($f_year !== '') $filter_sql .= " AND year='".mysqli_real_escape_string($connection, $f_year)."'";
if($f_sec  !== '') $filter_sql .= " AND sec_no='".mysqli_real_escape_string($connection, $f_sec)."'";

function filter_hidden() {
    global $f_sem, $f_year, $f_sec;
    echo '<input type="hidden" name="f_semester" value="'.htmlspecialchars($f_sem).'">';
    echo '<input type="hidden" name="f_year" value="'.htmlspecialchars($f_year).'">';
    echo '<input type="hidden" name="f_section" value="'.htmlspecialchars($f_sec).'">';
}

// Handle New Student Insert
if(isset($_POST['insert_student'])){
    $s_id = mysqli_real_escape_string($connection, $_POST['s_id']);
    $name = mysqli_real_escape_string($connection, $_POST['name']);
    $grade = mysqli_real_escape_string($connection, $_POST['grade']);
    $course_code = mysqli_real_escape_string($connection, $_POST['course_code']);
    $sec_no = mysqli_real_escape_string($connection, $_POST['sec_no']);
    $semester = mysqli_real_escape_string($connection, $_POST['semester']);
    $year = mysqli_real_escape_string($connection, $_POST['year']);

    if(!empty($s_id) && !empty($name)){
        $ins_sql = "INSERT INTO student (s_id, name, grade, course_code, sec_no, semester, year) VALUES ('$s_id', '$name', '$grade', '$course_code', '$sec_no', '$semester', '$year')";
        if(mysqli_query($connection, $ins_sql)){
            audit_log($connection, $username, 'INSERT', $s_id, "Added $course_code ($sec_no) $semester $year, grade $grade");
            echo '<script type="text/javascript">setTimeout(function () { swal("Success!", "Student record added successfully!", "success"); },300);</script>';
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Student Outcome Analysis - OBE & Skill Mapping Portal</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="../css/style_2.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="../css/bootstrap.min.css">
  <script src="../js/sweetalert.min.js"></script>
  <script src="../js/jquery-3.2.1.min.js"></script>
  <script src="../js/bootstrap.min.js"></script>
  <!-- Chart.js Library -->
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <!-- PDF export library -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
  <style>
      /* =====================================================
         BLACK PAGE BACKGROUND + COLORFUL & CLEAR INNER THEME
         ===================================================== */
      body { background-color: #050508 !important; color: #f2f2f7; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
      h3, h4, h5 { color: #ffffff; }
      label { color: #cfd3ff !important; font-weight: 600; }
      hr { border-color: #2b2b44; }
      .text-muted { color: #a9aed0 !important; }

      /* ---------- Sidebar ---------- */
      #tbl1 { background: linear-gradient(180deg, #1a1440 0%, #10213f 55%, #0b2a2a 100%) !important; border: 1px solid #2e2e5a; }
      #tbl1 a { color: #e6e8ff !important; font-weight: 600; text-decoration: none; display: block; padding: 8px 10px; border-radius: 6px; transition: 0.2s; }
      #tbl1 a:hover { background: linear-gradient(90deg, #6c5ce7, #00b4d8); color: #ffffff !important; padding-left: 15px; }
      #tbl1 a:nth-of-type(2) i { color: #4fc3f7; }
      #tbl1 a:nth-of-type(3) i { color: #ffb74d; }
      #tbl1 a:nth-of-type(4) i { color: #81c784; }
      #tbl1 a:nth-of-type(5) i { color: #f06292; }
      #tbl1 a:nth-of-type(6) i { color: #ba68c8; }
      #tbl1 a:nth-of-type(7) i { color: #4dd0e1; }
      #tbl1 a:nth-of-type(8) i { color: #fff176; }
      #tbl1 a:nth-of-type(9) i { color: #ff8a65; }

      /* ---------- Cards ---------- */
      .card-custom { background: linear-gradient(145deg, #181830 0%, #10101f 100%); border-radius: 10px; box-shadow: 0 6px 22px rgba(0,0,0,0.65); padding: 20px; margin-bottom: 25px; border-top: 4px solid #6c5ce7; border-left: 1px solid #2c2c52; border-right: 1px solid #2c2c52; border-bottom: 1px solid #2c2c52; }
      .card-add    { border-top-color: #2ecc71; background: linear-gradient(145deg, #12302a 0%, #0e1a1a 100%); border-color: #1f4d40; }
      .card-search { border-top-color: #00b4d8; background: linear-gradient(145deg, #11294a 0%, #0e1526 100%); border-color: #1f4670; }
      .card-log    { border-top-color: #e056fd; background: linear-gradient(145deg, #2a1440 0%, #150e22 100%); border-color: #4a2670; }
      .card-add h4    { color: #5cf2a5 !important; }
      .card-search h4 { color: #5ccfff !important; }
      .card-log h4    { color: #f08bff !important; }

      .charts-wrapper { display: flex; justify-content: space-around; flex-wrap: wrap; margin-top: 20px; gap: 20px; }
      .chart-box { width: 48%; min-width: 280px; background: #121226; padding: 15px; border-radius: 8px; border: 1px solid #2c2c52; border-top: 3px solid #6c5ce7; }
      .chart-box:nth-child(1) { border-top-color: #2ecc71; background: linear-gradient(160deg, #11291f, #0e0e1c); }
      .chart-box:nth-child(2) { border-top-color: #3498db; background: linear-gradient(160deg, #10233f, #0e0e1c); }
      .chart-box:nth-child(3) { border-top-color: #e056fd; background: linear-gradient(160deg, #281440, #0e0e1c); }
      .chart-box:nth-child(4) { border-top-color: #ffb300; background: linear-gradient(160deg, #33250c, #0e0e1c); }
      .chart-box h5 { color: #ffffff !important; }
      .chart-box.full { width: 100%; }
      .chart-container { position: relative; height: 260px; width: 100%; display: flex; justify-content: center; align-items: center; }

      /* ---------- KPI cards (each its own color) ---------- */
      .kpi-row { display: flex; gap: 15px; flex-wrap: wrap; margin-top: 15px; }
      .kpi { flex: 1; min-width: 150px; background: #151528; border-left: 5px solid #8a8aff; padding: 12px 15px; border-radius: 8px; box-shadow: 0 3px 10px rgba(0,0,0,0.45); }
      .kpi .val { font-size: 26px; font-weight: bold; color: #ffffff; }
      .kpi .lbl { font-size: 12px; color: #d4d7f5; text-transform: uppercase; letter-spacing: 0.4px; }
      .kpi:nth-child(1) { background: linear-gradient(135deg, #2b2370, #151528); border-left-color: #8e7bff; }
      .kpi:nth-child(2) { background: linear-gradient(135deg, #0f3f66, #151528); border-left-color: #3498db; }
      .kpi:nth-child(3) { background: linear-gradient(135deg, #4a1f66, #151528); border-left-color: #c36bff; }
      .kpi:nth-child(4) { background: linear-gradient(135deg, #0f5a3a, #151528); border-left-color: #2ecc71; }
      .kpi:nth-child(5) { background: linear-gradient(135deg, #66400f, #151528); border-left-color: #ffa726; }
      .kpi:nth-child(6) { background: linear-gradient(135deg, #5a1a24, #151528); }

      .decision-box { margin-top: 15px; padding: 14px 16px; border-radius: 8px; border-left: 6px solid; color: #f2f2f7; line-height: 1.6; }
      .progress { margin-bottom: 0; height: 18px; background-color: #26264a; box-shadow: none; border-radius: 10px; }
      .progress-bar-success { background-image: linear-gradient(90deg, #11998e, #38ef7d); }
      .progress-bar-warning { background-image: linear-gradient(90deg, #f7971e, #ffd200); }
      .progress-bar-danger  { background-image: linear-gradient(90deg, #cb2d3e, #ff6a6a); }

      /* ---------- Inputs / forms ---------- */
      .form-control { background-color: #0d0d1d; color: #ffffff; border: 1px solid #3b3b70; box-shadow: none; }
      .form-control::placeholder { color: #8d92c0; }
      .form-control:focus { border-color: #00b4d8; box-shadow: 0 0 0 2px rgba(0,180,216,0.25); }
      select.form-control option { background: #0d0d1d; color: #fff; }

      /* ---------- Tables ---------- */
      .table { color: #f2f2f7; }
      .table-bordered, .table-bordered > thead > tr > th, .table-bordered > tbody > tr > td, .table-bordered > thead > tr > td { border-color: #34345e !important; }
      .table thead, thead { background: linear-gradient(90deg, #4b2fb8, #0a7ea4) !important; color: #ffffff !important; }
      .table > thead > tr > th { color: #ffffff; border-bottom: none; }
      .table-striped > tbody > tr:nth-of-type(odd) { background-color: #1a1a36; }
      .table-striped > tbody > tr:nth-of-type(even) { background-color: #121228; }
      .table-striped > tbody > tr:hover { background-color: #25254d; }

      /* ---------- Buttons ---------- */
      .btn { border: none; font-weight: 600; transition: 0.2s; }
      .btn-primary { background: linear-gradient(90deg, #6c5ce7, #0984e3); color: #fff; }
      .btn-primary:hover, .btn-primary:focus { background: linear-gradient(90deg, #7d6ff0, #2a96f0); color: #fff; transform: translateY(-1px); }
      .btn-default { background: linear-gradient(90deg, #2d3a6b, #1f5a7a); color: #fff; }
      .btn-default:hover { background: linear-gradient(90deg, #3d4d8f, #2a7599); color: #fff; }
      .btn-success { background: linear-gradient(90deg, #11998e, #38ef7d); color: #04251c; }
      .btn-success:hover { background: linear-gradient(90deg, #14b3a5, #5cf59a); color: #04251c; }

      /* ---------- Alerts ---------- */
      .alert-warning { background-color: #3a2c0c; border-color: #6b5214; color: #ffd98a; }
      .alert-success { background-color: #0f3323; border-color: #1f6b49; color: #8bf0b8; }
      .alert-danger  { background-color: #3a1214; border-color: #7a2a2d; color: #ffa8a3; }
      textarea.form-control { resize: vertical; }

      .badge-risk { display: inline-block; padding: 6px 14px; border-radius: 20px; font-size: 13px; font-weight: bold; color: #fff; vertical-align: middle; box-shadow: 0 2px 8px rgba(0,0,0,0.5); }
      .rec-list li { margin-bottom: 6px; }
      .batch-card { background: linear-gradient(135deg, #1b1b3d, #11112a); border: 1px solid #34345e; border-left: 4px solid #00b4d8; border-radius: 8px; padding: 12px 15px; margin-bottom: 10px; }
      .action-bar { display: flex; gap: 10px; flex-wrap: wrap; align-items: center; }
      .label-success { background-color: #1fb36b; }
      .label-primary { background-color: #4c6ef5; }
      .label-danger  { background-color: #e03131; }
      .label-default { background-color: #5a5f8a; }

      /* Light mode used only for Print / PDF output */
      body.pdf-mode, body.pdf-mode .card-custom, body.pdf-mode .chart-box, body.pdf-mode .kpi, body.pdf-mode .batch-card { background: #ffffff !important; background-image: none !important; color: #000 !important; }
      body.pdf-mode h3, body.pdf-mode h4, body.pdf-mode h5, body.pdf-mode label, body.pdf-mode .kpi .val, body.pdf-mode .kpi .lbl, body.pdf-mode .chart-box h5, body.pdf-mode .table { color: #000 !important; }
      body.pdf-mode .table-striped > tbody > tr { background: #fff !important; }
      body.pdf-mode .table thead, body.pdf-mode thead { background: #222 !important; background-image: none !important; }
      body.pdf-mode .form-control { background: #fff; color: #000; border-color: #999; }
      body.pdf-mode .decision-box { color: #000; background: #f5f5f5 !important; }
      @media print {
          body * { visibility: hidden; }
          #reportArea, #reportArea * { visibility: visible; }
          #reportArea { position: absolute; left: 0; top: 0; width: 100%; }
          .no-print { display: none !important; }
      }
  </style>
</head>
<body>
   <div id="function">
	   <div>
			<nav class="navbar navbar-default" id="nb" style="background: linear-gradient(90deg, #000000, #1a1040 50%, #000000); border: none; border-bottom: 2px solid #6c5ce7; border-radius: 0; margin-bottom: 0;">
			  <div class="container-fluid">
			    <div class="navbar-header">
			      <a class="navbar-brand" href="#" style="color: #ffffff !important; font-weight: bold; font-size: 20px;"><i class="fa fa-graduation-cap" style="color:#ffd54f;"></i> Outcome-Based Education (OBE) &amp; Skill Mapping Portal</a>
			    </div>
			  </div>
		  </nav>

      <div style="width:98%; margin:15px auto; display: flex;" id="nb2">
       
       <!-- Sidebar -->
       <table id="tbl1" width="18%" height="600px" style="flex-shrink: 0; box-shadow: 2px 0 10px rgba(0,0,0,0.5); padding: 15px; border-radius: 8px;">
        <tr><td valign="top"><br>
          <a href="#" class="glyphicon glyphicon-user" style="font-weight: bold; color: #ffffff !important; font-size: 15px;"> UITS Admin</a><br><hr>
          <a href="admin_dashboard.php"><i class="fa fa-home"></i> Dashboard</a><br>
          <a href="department.php"><i class="fa fa-building-o"></i> Department</a><br>
          <a href="course.php"><i class="fa fa-book"></i> Course</a><br>
          <a href="offered_course.php"><i class="fa fa-bookmark-o"></i> Offer Course</a><br>
          <a href="assign_course.php"><i class="fa fa-tasks"></i> Assign Course</a><br>
          <a href="component.php"><i class="fa fa-cubes"></i> Component</a><br>
          <a href="history.php" style="background: linear-gradient(90deg, #6c5ce7, #00b4d8); color: #ffffff !important;"><i class="fa fa-line-chart"></i> Outcome Analysis</a><br>
		  <a href="st_enrollment.php"><i class="fa fa-users"></i> Student Enrollment</a><br><br><hr>
          <a href="../logout.php" class="glyphicon glyphicon-log-out" style="color: #ff6b6b !important;"> Logout</a>
          </td>
        </tr>
      </table>  

	  <!-- Main Content -->
	  <div style="flex-grow: 1; padding: 0 25px; margin-left: 20px; min-width: 0;">
	    
        <!-- Page Header -->
        <div style="background: linear-gradient(135deg, #2b1a6b 0%, #0f3d6b 60%, #0b5a5a 100%); padding: 15px 20px; border-radius: 10px; border: 1px solid #3d3d8a; box-shadow: 0 4px 14px rgba(0,0,0,0.6); margin-bottom: 20px; display: flex; justify-content: space-between; align-items: center;">
            <h3 style="margin: 0; color: #ffffff; font-weight: bold;"><i class="fa fa-line-chart" style="color: #ffd54f;"></i> Student Outcome Analysis &amp; Gap Report</h3>
            <span class="badge" style="background: linear-gradient(90deg, #e056fd, #6c5ce7); font-size: 13px; padding: 8px 12px;">Session: Fall 2026</span>
        </div>

		<!-- Add New Student Form Card -->
		<div class="card-custom card-add">
			<h4 style="margin-top: 0; color: #ffffff; font-weight: bold; border-bottom: 1px solid #1f4d40; padding-bottom: 10px;"><i class="fa fa-user-plus"></i> Add New Student Record (Multiple Courses Support)</h4>
			<form method="POST" action="">
				<div class="row">
					<div class="col-md-2">
						<label style="font-size: 13px;">Student ID:</label>
						<input type="text" name="s_id" class="form-control" placeholder="Ex: 99" required>
					</div>
					<div class="col-md-3">
						<label style="font-size: 13px;">Student Name:</label>
						<input type="text" name="name" class="form-control" placeholder="Ex: Zahid" required>
					</div>
					<div class="col-md-2">
						<label style="font-size: 13px;">Grade:</label>
						<input type="text" name="grade" class="form-control" value="A+" placeholder="Ex: A+" required>
					</div>
					<div class="col-md-2">
						<label style="font-size: 13px;">Course Code:</label>
						<input type="text" name="course_code" class="form-control" placeholder="Ex: CSE416" required>
					</div>
					<div class="col-md-1">
						<label style="font-size: 13px;">Section:</label>
						<input type="text" name="sec_no" class="form-control" value="B" required>
					</div>
					<div class="col-md-2">
						<label style="font-size: 13px;">Semester:</label>
						<input type="text" name="semester" class="form-control" value="Fall" required>
					</div>
				</div>
				<br>
				<div class="row">
					<div class="col-md-2">
						<label style="font-size: 13px;">Year:</label>
						<input type="text" name="year" class="form-control" value="2026" required>
					</div>
					<div class="col-md-3">
                        <label>&nbsp;</label>
						<button type="submit" name="insert_student" class="btn btn-success btn-block" style="font-weight: bold;"><i class="fa fa-plus-circle"></i> Save Student Record</button>
					</div>
				</div>
			</form>
		</div>

		<!-- Search Student Section Card -->
		<div class="card-custom card-search">
			<h4 style="margin-top: 0; color: #ffffff; font-weight: bold; border-bottom: 1px solid #1f4670; padding-bottom: 10px;"><i class="fa fa-search"></i> Search Student Outcome Attainment</h4>

			<!-- NEW: Advanced Search & Filter -->
			<form method="POST" action="" style="margin-bottom: 15px; padding-bottom: 15px; border-bottom: 1px dashed #2f5f94;">
				<div class="row">
					<div class="col-md-3">
						<label style="font-size: 13px;"><i class="fa fa-filter"></i> Semester:</label>
						<select name="f_semester" class="form-control">
							<option value="">All Semesters</option>
							<?php $o = mysqli_query($connection, "SELECT DISTINCT semester FROM student ORDER BY semester");
							while($o && ($ro = mysqli_fetch_assoc($o))){ $sel = ($f_sem === $ro['semester']) ? 'selected' : ''; echo "<option value='".htmlspecialchars($ro['semester'])."' $sel>".htmlspecialchars($ro['semester'])."</option>"; } ?>
						</select>
					</div>
					<div class="col-md-3">
						<label style="font-size: 13px;">Year:</label>
						<select name="f_year" class="form-control">
							<option value="">All Years</option>
							<?php $o = mysqli_query($connection, "SELECT DISTINCT year FROM student ORDER BY year DESC");
							while($o && ($ro = mysqli_fetch_assoc($o))){ $sel = ($f_year === (string)$ro['year']) ? 'selected' : ''; echo "<option value='".htmlspecialchars($ro['year'])."' $sel>".htmlspecialchars($ro['year'])."</option>"; } ?>
						</select>
					</div>
					<div class="col-md-3">
						<label style="font-size: 13px;">Section:</label>
						<select name="f_section" class="form-control">
							<option value="">All Sections</option>
							<?php $o = mysqli_query($connection, "SELECT DISTINCT sec_no FROM student ORDER BY sec_no");
							while($o && ($ro = mysqli_fetch_assoc($o))){ $sel = ($f_sec === $ro['sec_no']) ? 'selected' : ''; echo "<option value='".htmlspecialchars($ro['sec_no'])."' $sel>".htmlspecialchars($ro['sec_no'])."</option>"; } ?>
						</select>
					</div>
					<div class="col-md-3">
						<label>&nbsp;</label><br>
						<button type="submit" name="apply_filter" class="btn btn-default"><i class="fa fa-filter"></i> Apply</button>
						<a href="history.php" class="btn btn-default"><i class="fa fa-refresh"></i> Reset</a>
					</div>
				</div>
			</form>

			<?php 
				$select = mysqli_query($connection, "SELECT DISTINCT s_id, name FROM student WHERE 1=1 $filter_sql");
				if($select && mysqli_num_rows($select) > 0) {
					$chosen = isset($_POST['select_id']) ? $_POST['select_id'] : '';
			?>
			<form method="POST" action="">
				<?php filter_hidden(); ?>
				<div class="row">
					<div class="col-md-5">
    					<select name="select_id" class="form-control" style="font-weight: 500;">
    					<?php	
    						while ($row = mysqli_fetch_array($select)) {  
             			?>
                			<option value="<?php echo $row['s_id']; ?>" <?php echo ($chosen == $row['s_id']) ? 'selected' : ''; ?>>ID: <?php echo $row['s_id']; ?> — Name: <?php echo $row['name']; ?></option>
                		<?php
                    		}
						?>
						</select>
    				</div>
    				<div class="col-md-3"> 
                		<input type="submit" name="search_student" value="Calculate & View Outcome Report" class="btn btn-primary" style="font-weight: bold;">
        			</div>
    			</div>
            </form>
			<?php 
				} else {
					echo "<div class='alert alert-warning' style='margin-bottom:0;'>No student records found for the selected filter. Please change the filter or add a student using the form above.</div>";
				}
			?>
		</div>

		<?php
		if(isset($_POST['search_student']) || isset($_POST['save_remarks']) || isset($_POST['send_email'])){
			$select_id = mysqli_real_escape_string($connection, $_POST['select_id']);
			$st_query = mysqli_query($connection, "SELECT * FROM student WHERE s_id='$select_id' $filter_sql");
			if($st_query && mysqli_num_rows($st_query) > 0){

				/* ---------- CALCULATION ENGINE ---------- */
				$rows = [];          // per-course result
				$seen = [];          // duplicate row filter
				$student_id = ''; $student_name = '';
				while($r = mysqli_fetch_assoc($st_query)){
					$student_id = $r['s_id']; $student_name = $r['name'];
					$key = $r['course_code'].'|'.$r['sec_no'].'|'.$r['semester'].'|'.$r['year'];
					if(isset($seen[$key])) continue;   // same course dobar thakle skip
					$seen[$key] = true;

					$g = strtoupper(trim($r['grade']));
					$base = isset($grade_scale[$g]) ? $grade_scale[$g] : 0;

					// CO attainment (grade-based; marks table thakle ekhane replace korben)
					$co = [
						'CO1' => min(100, max(0, $base + 3)),
						'CO2' => min(100, max(0, $base - 5)),
					];

					// CO -> PO weighted mapping
					$po = [];
					foreach($po_list as $p){
						$num = 0; $den = 0;
						foreach($co_po_map as $c => $targets){
							if(isset($targets[$p])){
								$num += $co[$c] * $targets[$p];
								$den += $targets[$p];
							}
						}
						$po[$p] = $den > 0 ? round($num / $den, 1) : 0;
					}

					$accepted = []; $rejected = [];
					foreach($po as $p => $v){
						if($v >= TARGET_ATTAINMENT) $accepted[] = $p; else $rejected[] = $p;
					}
					$avg_po = round(array_sum($po) / count($po), 1);

					if(count($rejected) == 0)               $decision = 'Attained';
					elseif(count($accepted) > 0)            $decision = 'Partially Attained – CQI Needed';
					else                                    $decision = 'Not Attained – Remedial/Retake';

					$rows[] = [
						'course'=>$r['course_code'], 'sec'=>$r['sec_no'], 'grade'=>$r['grade'],
						'sem'=>$r['semester'].' '.$r['year'],
						'semester_raw'=>$r['semester'], 'year_raw'=>$r['year'],
						'co'=>$co, 'po'=>$po, 'accepted'=>$accepted, 'rejected'=>$rejected,
						'avg_po'=>$avg_po, 'decision'=>$decision
					];
				}

				// Overall PO attainment across all courses
				$overall_po = [];
				foreach($po_list as $p){
					$sum = 0; foreach($rows as $x) $sum += $x['po'][$p];
					$overall_po[$p] = round($sum / count($rows), 1);
				}
				$overall_avg = round(array_sum($overall_po) / count($overall_po), 1);
				$overall_co1 = round(array_sum(array_map(function($x){return $x['co']['CO1'];}, $rows)) / count($rows), 1);
				$overall_co2 = round(array_sum(array_map(function($x){return $x['co']['CO2'];}, $rows)) / count($rows), 1);

				$acc_po = []; $part_po = []; $rej_po = [];
				foreach($overall_po as $p => $v){
					$s = status_of($v);
					if($s == 'Attained') $acc_po[] = $p; elseif($s == 'Partial') $part_po[] = $p; else $rej_po[] = $p;
				}

				// Final decision
				if($overall_avg >= 75)      { $final = 'Excellent – Skill Ready';        $fcolor = '#2ecc71'; $fbg = '#0f3323'; $note = 'Student sob PO te strong. Advanced course/project/internship e recommend kora jay.'; }
				elseif($overall_avg >= 60)  { $final = 'Satisfactory – Outcomes Achieved'; $fcolor = '#4dabf7'; $fbg = '#0f2a47'; $note = 'Target outcome achieve hoyeche. Weak PO gulo te extra practice/lab support dewa jete pare.'; }
				elseif($overall_avg >= 40)  { $final = 'Needs Improvement – CQI Required'; $fcolor = '#ffa94d'; $fbg = '#3d2a0e'; $note = 'Kisu PO target er niche. Remedial class, assignment-based support o mentoring dorkar.'; }
				else                        { $final = 'Critical – Retake / Intervention'; $fcolor = '#ff6b6b'; $fbg = '#3a1214'; $note = 'Most PO not attained. Course retake ba academic advisor intervention recommended.'; }

				/* ---------- NEW 3: Student Risk & Status Badge ---------- */
				if($overall_avg < CRITICAL_LIMIT)      { $risk_label = 'At Risk';           $risk_color = '#c0392b'; $risk_icon = 'fa-exclamation-triangle'; }
				elseif($overall_avg < RISK_LIMIT)      { $risk_label = 'Needs Improvement'; $risk_color = '#d35400'; $risk_icon = 'fa-exclamation-circle'; }
				else                                   { $risk_label = 'On Track';          $risk_color = '#27ae60'; $risk_icon = 'fa-check-circle'; }

				/* ---------- NEW 5: Batch / Course Summary ---------- */
				$batch = [];
				foreach($rows as $x){
					$bq = mysqli_query($connection, "SELECT s_id, grade FROM student WHERE course_code='".mysqli_real_escape_string($connection,$x['course'])."' AND sec_no='".mysqli_real_escape_string($connection,$x['sec'])."' AND semester='".mysqli_real_escape_string($connection,$x['semester_raw'])."' AND year='".mysqli_real_escape_string($connection,$x['year_raw'])."'");
					$tot = 0; $pass = 0; $sum = 0; $seen_s = [];
					while($bq && ($b = mysqli_fetch_assoc($bq))){
						if(isset($seen_s[$b['s_id']])) continue;
						$seen_s[$b['s_id']] = true;
						$res = calc_po_avg($b['grade']);
						$tot++; $sum += $res;
						if($res >= TARGET_ATTAINMENT) $pass++;
					}
					$batch[] = [
						'label'=>$x['course'].' (Sec '.$x['sec'].') — '.$x['sem'],
						'total'=>$tot,
						'avg'=>$tot ? round($sum / $tot, 1) : 0,
						'pass_rate'=>$tot ? round(($pass / $tot) * 100, 1) : 0
					];
				}

				/* ---------- NEW 9: Quick Action Remedial Recommendation ---------- */
				$recs = [];
				foreach(['CO1'=>$overall_co1, 'CO2'=>$overall_co2] as $c => $v){
					$s = status_of($v);
					if($s == 'Not Attained')   $recs[] = "Extra tutorial class strongly recommended for $c ($v%).";
					elseif($s == 'Partial')    $recs[] = "Extra tutorial class recommended for $c ($v%).";
				}
				foreach($overall_po as $p => $v){
					$s = status_of($v);
					if($s == 'Not Attained')   $recs[] = "$p is critically low ($v%): assign remedial assignment and lab/practice support.";
					elseif($s == 'Partial')    $recs[] = "$p is partially attained ($v%): assign mentoring and extra practice work.";
				}
				if($overall_avg < RISK_LIMIT)  $recs[] = "Overall attainment is below ".RISK_LIMIT."%: academic advisor meeting recommended.";
				if(count($recs) == 0)          $recs[] = "No remedial action needed. Student may be recommended for advanced course / project / internship.";

				/* ---------- NEW 2: CQI Remarks (save + load) ---------- */
				$flash = '';
				$gap_items = [];
				foreach(['CO1'=>$overall_co1, 'CO2'=>$overall_co2] as $c => $v){ if($v < TARGET_ATTAINMENT) $gap_items[$c] = $v; }
				foreach($overall_po as $p => $v){ if($v < TARGET_ATTAINMENT) $gap_items[$p] = $v; }

				if(isset($_POST['save_remarks']) && isset($_POST['remark']) && is_array($_POST['remark'])){
					$sid_esc = mysqli_real_escape_string($connection, $student_id);
					$uname_esc = mysqli_real_escape_string($connection, $username);
					foreach($_POST['remark'] as $item => $text){
						if(!preg_match('/^(PO|CO)\d+$|^GENERAL$/', $item)) continue;
						$text = trim($text);
						$text_esc = mysqli_real_escape_string($connection, $text);
						if($text === ''){
							mysqli_query($connection, "DELETE FROM cqi_remarks WHERE s_id='$sid_esc' AND item='$item'");
						} else {
							mysqli_query($connection, "INSERT INTO cqi_remarks (s_id, item, remark, updated_by) VALUES ('$sid_esc','$item','$text_esc','$uname_esc') ON DUPLICATE KEY UPDATE remark=VALUES(remark), updated_by=VALUES(updated_by)");
						}
					}
					audit_log($connection, $username, 'REMARK_SAVE', $student_id, 'CQI action plan / remarks updated');
					$flash .= "<div class='alert alert-success no-print'><i class='fa fa-check'></i> CQI remarks saved successfully.</div>";
				}
				$saved_remarks = [];
				$rq = mysqli_query($connection, "SELECT item, remark FROM cqi_remarks WHERE s_id='".mysqli_real_escape_string($connection, $student_id)."'");
				while($rq && ($rr = mysqli_fetch_assoc($rq))) $saved_remarks[$rr['item']] = $rr['remark'];

				/* ---------- NEW 10: Direct Email Report Sender ---------- */
				if(isset($_POST['send_email'])){
					$to = isset($_POST['email_to']) ? trim($_POST['email_to']) : '';
					if(filter_var($to, FILTER_VALIDATE_EMAIL)){
						$body  = "OBE Attainment Report\n";
						$body .= "=====================================\n";
						$body .= "Student: $student_name (ID: $student_id)\n";
						$body .= "Courses Taken: ".count($rows)."\n";
						$body .= "Avg CO1: $overall_co1% | Avg CO2: $overall_co2%\n";
						foreach($overall_po as $p => $v) $body .= "$p: $v% (".status_of($v).")\n";
						$body .= "Overall PO Attainment: $overall_avg% (Target: ".TARGET_ATTAINMENT."%)\n";
						$body .= "Status: $risk_label\n";
						$body .= "Final Decision: $final\n\n";
						$body .= "Recommendations:\n";
						foreach($recs as $rc) $body .= " - $rc\n";
						if(count($saved_remarks)){
							$body .= "\nCQI Remarks:\n";
							foreach($saved_remarks as $it => $tx) $body .= " [$it] $tx\n";
						}
						$headers = "From: obe-portal@uits.edu.bd\r\nContent-Type: text/plain; charset=UTF-8\r\n";
						if(@mail($to, "OBE Attainment Report - $student_name ($student_id)", $body, $headers)){
							audit_log($connection, $username, 'EMAIL_SENT', $student_id, "Report emailed to $to");
							$flash .= "<div class='alert alert-success no-print'><i class='fa fa-envelope'></i> Report sent to ".htmlspecialchars($to).".</div>";
						} else {
							$flash .= "<div class='alert alert-danger no-print'>Email could not be sent. Please check the server mail configuration.</div>";
						}
					} else {
						$flash .= "<div class='alert alert-danger no-print'>Please enter a valid email address.</div>";
					}
				}

				/* ---------- NEW 8: Audit log for search ---------- */
				if(isset($_POST['search_student'])){
					audit_log($connection, $username, 'SEARCH', $student_id, "Viewed outcome report ($student_name)");
				}
		?>
        <!-- Result Presentation Card -->
        <div class="card-custom" style="border-top-color: #2ecc71; background: linear-gradient(145deg, #181838 0%, #0f1424 100%);" id="reportArea">
            <h4 style="margin-top: 0; color: #5cf2a5; font-weight: bold; border-bottom: 1px solid #2c2c52; padding-bottom: 10px;">
                <i class="fa fa-check-circle"></i> Attainment Analysis Result for Student ID: <?php echo $student_id; ?> (<?php echo $student_name; ?>)
                <span class="badge-risk" style="background: <?php echo $risk_color; ?>; margin-left: 10px;"><i class="fa <?php echo $risk_icon; ?>"></i> <?php echo $risk_label; ?></span>
            </h4>

            <?php echo $flash; ?>

            <!-- NEW 1: Print & PDF buttons -->
            <div class="action-bar no-print" style="margin-bottom: 5px;">
                <button type="button" class="btn btn-default" onclick="window.print()"><i class="fa fa-print"></i> Print Report</button>
                <button type="button" class="btn btn-default" onclick="downloadPDF()"><i class="fa fa-file-pdf-o"></i> Download PDF</button>
            </div>

            <!-- KPI Summary -->
            <div class="kpi-row">
                <div class="kpi"><div class="val"><?php echo count($rows); ?></div><div class="lbl">Courses Taken</div></div>
                <div class="kpi"><div class="val"><?php echo $overall_co1; ?>%</div><div class="lbl">Avg CO1 Attainment</div></div>
                <div class="kpi"><div class="val"><?php echo $overall_co2; ?>%</div><div class="lbl">Avg CO2 Attainment</div></div>
                <div class="kpi"><div class="val"><?php echo $overall_avg; ?>%</div><div class="lbl">Overall PO Attainment</div></div>
                <div class="kpi"><div class="val"><?php echo TARGET_ATTAINMENT; ?>%</div><div class="lbl">Target Threshold</div></div>
                <div class="kpi" style="border-left-color:<?php echo $risk_color; ?>;"><div class="val" style="color:#ffffff; font-size:18px;"><?php echo $risk_label; ?></div><div class="lbl">Student Status (&lt;<?php echo RISK_LIMIT; ?>% = Risk)</div></div>
            </div>

            <!-- Course-wise table -->
            <div class="table-responsive" style="margin-top: 20px;">
                <table class="table table-bordered table-striped" style="margin-bottom: 0;">
                    <thead style="color: white;">
                        <tr>
                            <th>SL</th>
                            <th>Course Code</th>
                            <th>Section</th>
                            <th>Grade</th>
                            <th>CO1 Attainment</th>
                            <th>CO2 Attainment</th>
                            <th>Accepted PO</th>
                            <th>Rejected PO (Gap)</th>
                            <th>Decision</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $sl = 1;
                        foreach($rows as $x){
                            $s1 = status_of($x['co']['CO1']); $s2 = status_of($x['co']['CO2']);
                            echo "<tr>";
                            echo "<td>".$sl."</td>";
                            echo "<td><strong>".$x['course']."</strong></td>";
                            echo "<td>".$x['sec']."</td>";
                            echo "<td><span class='label label-success' style='font-size:12px;'>".$x['grade']."</span></td>";
                            echo "<td><span style='color:".status_color($s1)."; font-weight: bold;'>".$x['co']['CO1']."% (".$s1.")</span></td>";
                            echo "<td><span style='color:".status_color($s2)."; font-weight: bold;'>".$x['co']['CO2']."% (".$s2.")</span></td>";
                            echo "<td>".(count($x['accepted']) ? "<span class='label label-primary'>".implode(', ', $x['accepted'])."</span>" : "<span class='label label-default'>None</span>")."</td>";
                            echo "<td>".(count($x['rejected']) ? "<span class='label label-danger'>".implode(', ', $x['rejected'])."</span>" : "<span class='label label-default'>None</span>")."</td>";
                            echo "<td style='font-weight:bold;'>".$x['decision']."</td>";
                            echo "</tr>";
                            $sl++;
                        }
                        ?>
                    </tbody>
                </table>
            </div>

            <!-- CO-PO Mapping Percentage -->
            <h4 style="color: #5ccfff; font-weight: bold; margin-top: 30px;"><i class="fa fa-sitemap"></i> CO → PO Mapping & PO Attainment (%)</h4>
            <div class="row">
                <div class="col-md-5">
                    <table class="table table-bordered" style="margin-bottom:10px;">
                        <thead><tr><th>CO</th><?php foreach($po_list as $p) echo "<th>$p</th>"; ?></tr></thead>
                        <tbody>
                        <?php foreach($co_po_map as $c => $targets){
                            echo "<tr><td><strong>$c</strong></td>";
                            foreach($po_list as $p) echo "<td>".(isset($targets[$p]) ? $targets[$p].'%' : '—')."</td>";
                            echo "</tr>";
                        } ?>
                        </tbody>
                    </table>
                    <small class="text-muted">Mapping weight: CO ta PO te koto % contribute kore.</small>
                </div>
                <div class="col-md-7">
                    <?php foreach($overall_po as $p => $v){
                        $s = status_of($v);
                        $cls = $s == 'Attained' ? 'progress-bar-success' : ($s == 'Partial' ? 'progress-bar-warning' : 'progress-bar-danger');
                        echo "<div style='margin-bottom:10px;'><strong>$p</strong> <span class='pull-right'>$v% — $s</span>";
                        echo "<div class='progress'><div class='progress-bar $cls' style='width:{$v}%'></div></div></div>";
                    } ?>
                </div>
            </div>

            <!-- Decision -->
            <div class="decision-box" style="background: <?php echo $fbg; ?>; border-color: <?php echo $fcolor; ?>;">
                <strong style="color: <?php echo $fcolor; ?>; font-size: 16px;"><i class="fa fa-gavel"></i> Final Decision: <?php echo $final; ?></strong><br>
                <span><strong>Accepted PO:</strong> <?php echo count($acc_po) ? implode(', ', $acc_po) : 'None'; ?>
                &nbsp;|&nbsp; <strong>Partial:</strong> <?php echo count($part_po) ? implode(', ', $part_po) : 'None'; ?>
                &nbsp;|&nbsp; <strong>Rejected (Gap):</strong> <?php echo count($rej_po) ? implode(', ', $rej_po) : 'None'; ?></span><br>
                <span><strong>CQI Note:</strong> <?php echo $note; ?></span>
            </div>

            <!-- NEW 9: Quick Action Remedial Recommendation -->
            <div class="decision-box" style="background: linear-gradient(135deg, #2a1f4d, #14142b); border-color: #b197fc;">
                <strong style="font-size: 15px; color: #d0bfff;"><i class="fa fa-lightbulb-o" style="color:#ffd54f;"></i> Quick Action – Remedial Recommendation</strong>
                <ul class="rec-list" style="margin: 8px 0 0 0; padding-left: 20px;">
                    <?php foreach($recs as $rc) echo "<li>".htmlspecialchars($rc)."</li>"; ?>
                </ul>
            </div>

            <!-- NEW 5: Batch / Course Summary -->
            <h4 style="color: #f08bff; font-weight: bold; margin-top: 30px;"><i class="fa fa-users"></i> Batch / Course Summary Overview</h4>
            <div class="row">
                <?php foreach($batch as $b){ ?>
                <div class="col-md-6">
                    <div class="batch-card">
                        <strong><?php echo htmlspecialchars($b['label']); ?></strong>
                        <div style="margin-top: 8px; display:flex; gap: 20px; flex-wrap: wrap;">
                            <span><i class="fa fa-user"></i> Students: <strong><?php echo $b['total']; ?></strong></span>
                            <span>Avg Attainment: <strong><?php echo $b['avg']; ?>%</strong></span>
                            <span>Pass Rate: <strong style="color: <?php echo status_color(status_of($b['pass_rate'])); ?>;"><?php echo $b['pass_rate']; ?>%</strong></span>
                        </div>
                        <div class="progress" style="margin-top: 8px;"><div class="progress-bar progress-bar-success" style="width: <?php echo $b['pass_rate']; ?>%"></div></div>
                    </div>
                </div>
                <?php } ?>
            </div>

            <!-- NEW 2: CQI Action Plan / Remarks Box -->
            <h4 style="color: #ffd54f; font-weight: bold; margin-top: 25px;"><i class="fa fa-pencil-square-o"></i> CQI Action Plan / Remarks</h4>
            <form method="POST" action="">
                <?php filter_hidden(); ?>
                <input type="hidden" name="select_id" value="<?php echo htmlspecialchars($student_id); ?>">
                <?php if(count($gap_items)){ foreach($gap_items as $item => $val){ ?>
                    <div class="form-group">
                        <label><?php echo $item; ?> — Gap Detected (<?php echo $val; ?>% / Target <?php echo TARGET_ATTAINMENT; ?>%) : Teacher / Admin Remarks</label>
                        <textarea name="remark[<?php echo $item; ?>]" class="form-control" rows="2" placeholder="Write corrective action / remarks for <?php echo $item; ?>..."><?php echo isset($saved_remarks[$item]) ? htmlspecialchars($saved_remarks[$item]) : ''; ?></textarea>
                    </div>
                <?php } } else { ?>
                    <div class="alert alert-success" style="margin-bottom: 10px;">No CO/PO gap found. Remarks are optional.</div>
                <?php } ?>
                <div class="form-group">
                    <label>General Remarks</label>
                    <textarea name="remark[GENERAL]" class="form-control" rows="2" placeholder="General comment / advisor note..."><?php echo isset($saved_remarks['GENERAL']) ? htmlspecialchars($saved_remarks['GENERAL']) : ''; ?></textarea>
                </div>
                <button type="submit" name="save_remarks" class="btn btn-primary no-print"><i class="fa fa-save"></i> Save CQI Remarks</button>
            </form>

            <!-- NEW 10: Email Report -->
            <div class="no-print" style="margin-top: 25px; padding-top: 15px; border-top: 1px dashed #3b3b70;">
                <h4 style="color: #5cf2a5; font-weight: bold;"><i class="fa fa-envelope-o"></i> Send Report by Email</h4>
                <form method="POST" action="">
                    <?php filter_hidden(); ?>
                    <input type="hidden" name="select_id" value="<?php echo htmlspecialchars($student_id); ?>">
                    <div class="row">
                        <div class="col-md-5">
                            <input type="email" name="email_to" class="form-control" placeholder="student@example.com / official address" required>
                        </div>
                        <div class="col-md-3">
                            <button type="submit" name="send_email" class="btn btn-primary"><i class="fa fa-paper-plane"></i> Send Report</button>
                        </div>
                    </div>
                </form>
            </div>

            <!-- Charts -->
            <div style="margin-top: 25px; padding-top: 15px; border-top: 1px dashed #3b3b70;">
                <h4 style="color: #ff9ecb; font-weight: bold;"><i class="fa fa-pie-chart"></i> CO & PO Attainment Analytics</h4>
                <div class="charts-wrapper">
                    <div class="chart-box">
                        <h5 style="text-align: center; font-weight: bold; margin-bottom: 15px;">PO Status Overview (Pie Chart)</h5>
                        <div class="chart-container"><canvas id="poPieChart"></canvas></div>
                    </div>
                    <div class="chart-box">
                        <h5 style="text-align: center; font-weight: bold; margin-bottom: 15px;">CO Attainment per Course (Bar Chart)</h5>
                        <div class="chart-container"><canvas id="coBarChart"></canvas></div>
                    </div>
                    <div class="chart-box">
                        <h5 style="text-align: center; font-weight: bold; margin-bottom: 15px;">PO Performance Comparison (Radar Chart)</h5>
                        <div class="chart-container"><canvas id="poRadarChart"></canvas></div>
                    </div>
                    <div class="chart-box">
                        <h5 style="text-align: center; font-weight: bold; margin-bottom: 15px;">PO Attainment Trend vs Target (Line Graph)</h5>
                        <div class="chart-container"><canvas id="poLineChart"></canvas></div>
                    </div>
                </div>
            </div>

            <script>
                const TARGET = <?php echo TARGET_ATTAINMENT; ?>;
                const PARTIAL = <?php echo PARTIAL_LIMIT; ?>;
                const courses = <?php echo json_encode(array_map(function($x){ return $x['course'].' ('.$x['sec'].')'; }, $rows)); ?>;
                const co1Data = <?php echo json_encode(array_map(function($x){ return $x['co']['CO1']; }, $rows)); ?>;
                const co2Data = <?php echo json_encode(array_map(function($x){ return $x['co']['CO2']; }, $rows)); ?>;
                const poLabels = <?php echo json_encode(array_keys($overall_po)); ?>;
                const poValues = <?php echo json_encode(array_values($overall_po)); ?>;
                const pieData  = [<?php echo count($acc_po); ?>, <?php echo count($part_po); ?>, <?php echo count($rej_po); ?>];
                const pieNames = [<?php echo json_encode($acc_po); ?>, <?php echo json_encode($part_po); ?>, <?php echo json_encode($rej_po); ?>];

                // Chart look for dark theme (brighter text for clarity)
                Chart.defaults.color = '#d4d7f5';
                Chart.defaults.borderColor = 'rgba(170,170,255,0.22)';

                function statusJS(v){ return v >= TARGET ? 'Attained' : (v >= PARTIAL ? 'Partial' : 'Not Attained'); }
                // NEW 7: interactive tooltips showing exact % and status
                const valueTooltip = {
                    callbacks: {
                        label: function(ctx){
                            const v = (ctx.parsed.y !== undefined ? ctx.parsed.y : ctx.parsed.r);
                            return ctx.dataset.label + ': ' + v + '%';
                        },
                        afterLabel: function(ctx){
                            const v = (ctx.parsed.y !== undefined ? ctx.parsed.y : ctx.parsed.r);
                            if(ctx.dataset.label.indexOf('Target') === 0) return '';
                            const gap = (v - TARGET).toFixed(1);
                            return 'Status: ' + statusJS(v) + '  |  ' + (gap >= 0 ? '+' : '') + gap + '% vs target';
                        }
                    }
                };

                // 1) PO Status Pie Chart
                new Chart(document.getElementById('poPieChart').getContext('2d'), {
                    type: 'pie',
                    data: {
                        labels: ['Accepted PO', 'Partially Attained PO', 'Rejected PO (Gap)'],
                        datasets: [{ data: pieData, backgroundColor: ['#2ecc71', '#ffb300', '#ff4d6d'], borderColor: '#10101f', borderWidth: 2 }]
                    },
                    options: { responsive: true, maintainAspectRatio: false,
                        plugins: { legend: { position: 'bottom' },
                            tooltip: { callbacks: {
                                label: function(ctx){ return ctx.label + ': ' + ctx.parsed + ' PO'; },
                                afterLabel: function(ctx){ const n = pieNames[ctx.dataIndex]; return n.length ? 'PO: ' + n.join(', ') : 'PO: None'; }
                            } } } }
                });

                // 2) CO Attainment Bar Chart (grouped) + target line
                new Chart(document.getElementById('coBarChart').getContext('2d'), {
                    data: {
                        labels: courses,
                        datasets: [
                            { type: 'bar',  label: 'CO1 %', data: co1Data, backgroundColor: '#4dabf7' },
                            { type: 'bar',  label: 'CO2 %', data: co2Data, backgroundColor: '#da77f2' },
                            { type: 'line', label: 'Target (' + TARGET + '%)', data: courses.map(() => TARGET),
                              borderColor: '#ff6b6b', borderDash: [6, 6], pointRadius: 0, fill: false }
                        ]
                    },
                    options: {
                        responsive: true, maintainAspectRatio: false,
                        scales: { y: { beginAtZero: true, max: 100, title: { display: true, text: 'Attainment (%)' } } },
                        plugins: { legend: { position: 'bottom' }, tooltip: valueTooltip },
                        interaction: { mode: 'index', intersect: false }
                    }
                });

                // 3) NEW 4: Radar / Spider Chart
                new Chart(document.getElementById('poRadarChart').getContext('2d'), {
                    type: 'radar',
                    data: {
                        labels: poLabels,
                        datasets: [
                            { label: 'PO Attainment %', data: poValues, borderColor: '#e056fd', backgroundColor: 'rgba(224,86,253,0.30)',
                              pointBackgroundColor: '#e056fd', pointRadius: 4 },
                            { label: 'Target (' + TARGET + '%)', data: poLabels.map(() => TARGET),
                              borderColor: '#ff6b6b', borderDash: [5, 5], pointRadius: 0, backgroundColor: 'transparent' }
                        ]
                    },
                    options: {
                        responsive: true, maintainAspectRatio: false,
                        scales: { r: { beginAtZero: true, max: 100, ticks: { stepSize: 20, backdropColor: 'transparent' } } },
                        plugins: { legend: { position: 'bottom' }, tooltip: valueTooltip }
                    }
                });

                // 4) PO Attainment Line Graph with target
                new Chart(document.getElementById('poLineChart').getContext('2d'), {
                    type: 'line',
                    data: {
                        labels: poLabels,
                        datasets: [
                            { label: 'PO Attainment %', data: poValues, borderColor: '#ffb300', backgroundColor: 'rgba(255,179,0,0.18)',
                              fill: true, tension: 0.3, pointRadius: 5, pointBackgroundColor: '#ffb300' },
                            { label: 'Target (' + TARGET + '%)', data: poLabels.map(() => TARGET),
                              borderColor: '#ff6b6b', borderDash: [6, 6], pointRadius: 0, fill: false }
                        ]
                    },
                    options: {
                        responsive: true, maintainAspectRatio: false,
                        scales: { y: { beginAtZero: true, max: 100, title: { display: true, text: 'Attainment (%)' } },
                                  x: { title: { display: true, text: 'Program Outcome' } } },
                        plugins: { legend: { position: 'bottom' }, tooltip: valueTooltip },
                        interaction: { mode: 'index', intersect: false }
                    }
                });

                // NEW 1: Print (light layout) & PDF download
                window.addEventListener('beforeprint', function(){ document.body.classList.add('pdf-mode'); });
                window.addEventListener('afterprint',  function(){ document.body.classList.remove('pdf-mode'); });
                function downloadPDF(){
                    document.body.classList.add('pdf-mode');
                    html2pdf().set({
                        margin: 8,
                        filename: 'OBE_Report_<?php echo preg_replace('/[^A-Za-z0-9_-]/', '', $student_id); ?>.pdf',
                        image: { type: 'jpeg', quality: 0.98 },
                        html2canvas: { scale: 2, backgroundColor: '#ffffff' },
                        jsPDF: { unit: 'mm', format: 'a4', orientation: 'landscape' }
                    }).from(document.getElementById('reportArea')).save().then(function(){
                        document.body.classList.remove('pdf-mode');
                    });
                }
            </script>
        </div>
		<?php
			} else {
				echo "<div class='alert alert-warning'>No data found for this student with the selected filter.</div>";
			}
		}
		?>

		<!-- NEW 8: Activity & Audit Log -->
		<div class="card-custom card-log no-print">
			<h4 style="margin-top: 0; color: #ffffff; font-weight: bold; border-bottom: 1px solid #4a2670; padding-bottom: 10px;"><i class="fa fa-history"></i> Activity & Audit Log (Last 10)</h4>
			<div class="table-responsive">
				<table class="table table-bordered table-striped" style="margin-bottom: 0;">
					<thead style="color: white;">
						<tr><th>Date &amp; Time</th><th>User</th><th>Action</th><th>Student ID</th><th>Details</th></tr>
					</thead>
					<tbody>
						<?php
						$lg = mysqli_query($connection, "SELECT * FROM obe_audit_log ORDER BY id DESC LIMIT 10");
						if($lg && mysqli_num_rows($lg) > 0){
							while($l = mysqli_fetch_assoc($lg)){
								echo "<tr><td>".htmlspecialchars($l['created_at'])."</td><td>".htmlspecialchars($l['username'])."</td><td><span class='label label-default'>".htmlspecialchars($l['action'])."</span></td><td>".htmlspecialchars($l['s_id'])."</td><td>".htmlspecialchars($l['details'])."</td></tr>";
							}
						} else {
							echo "<tr><td colspan='5' class='text-center text-muted'>No activity recorded yet.</td></tr>";
						}
						?>
					</tbody>
				</table>
			</div>
		</div>
	   </div>

	</div>
  </div>
</body>
</html>