<?php include("db.php");?>
<!DOCTYPE html>
<html>
<head>
  <title>Admin Dashboard</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="../css/style_2.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <style>
      body { background-color: #000000 !important; color: #e5e5e5; }

      /* Sidebar links */
      #tbl1 a {
          color: #d0d0d0 !important;
          font-weight: 600;
          text-decoration: none;
          display: block;
          padding: 5px 0;
          transition: 0.2s;
      }
      #tbl1 a:hover {
          color: #4da3ff !important;
          padding-left: 5px;
      }

      /* Card sub-label */
      .card-note {
          margin: 6px 0 0 0;
          font-size: 12px;
          opacity: 0.9;
      }
  </style>
</head>
<body>
   <div id="function">
     <div>
      <nav class="navbar navbar-default" id="nb" style="background: linear-gradient(135deg, #0a0a0a 0%, #1a1a1a 100%); border: none; border-bottom: 1px solid #222; border-radius: 0;">
        <div class="container-fluid">
          <div class="navbar-header">
            <a class="navbar-brand" href="#" style="color: #ffffff !important; font-weight: bold; font-size: 20px;"><i class="fa fa-tachometer"></i> UITS Admin Dashboard</a>
          </div>
        </div>
      </nav>

      <div style="width:95%; margin:0px auto ; display: flex;" id="nb2">
       <table id="tbl1" width="16%" height="565px" style="flex-shrink: 0; background: #0d0d0d; border-right: 1px solid #222; padding: 15px;">
        <tr><td valign="top"><br>
          <a href="#" class="glyphicon glyphicon-user" style="font-weight: bold; color: #4da3ff !important;"> UITS</a><br><br>
          <a href="admin_dashboard.php" style="background: #2a5298; color: #ffffff !important; padding: 8px 12px; border-radius: 4px;"><i class="fa fa-home"></i> Dashboard</a><br><br>
          <a href="department.php"><i class="fa fa-building-o"></i> Department</a><br><br>
          <a href="course.php"><i class="fa fa-book"></i> Course</a><br><br>
          <a href="offered_course.php"><i class="fa fa-bookmark-o"></i> Offer Course</a><br><br>
          <a href="assign_course.php"><i class="fa fa-tasks"></i> Assign Course</a><br><br>
          <a href="component.php"><i class="fa fa-cubes"></i> Component</a><br><br>
          <a href="history.php"><i class="fa fa-graduation-cap"></i> Student PO</a><br><br>
          <a href="st_enrollment.php"><i class="fa fa-users"></i> Student Enrollment</a><br><br><br>
          <a href="../logout.php" class="glyphicon glyphicon-log-out" style="color: #ff6b66 !important;"> Logout</a>
          </td>
        </tr>
      </table>

      <!-- Main Content Area -->
      <div style="flex-grow: 1; padding: 25px; background-color: #000000; min-height: 565px;">

          <!-- Welcome Banner -->
          <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 30px; border-radius: 12px; box-shadow: 0 10px 20px rgba(102, 126, 234, 0.2); margin-bottom: 25px; color: #ffffff; display: flex; justify-content: space-between; align-items: center;">
              <div>
                  <h1 style="margin: 0; font-size: 26px; font-weight: bold;">Welcome Back, Admin!</h1>
                  <p style="margin: 8px 0 0 0; font-size: 15px; opacity: 0.9;">UITS Outcome-Based Education (OBE) Result Management System</p>
              </div>
              <div>
                  <span style="background: rgba(255, 255, 255, 0.2); backdrop-filter: blur(5px); color: #ffffff; padding: 8px 18px; border-radius: 20px; font-size: 14px; font-weight: bold; border: 1px solid rgba(255,255,255,0.3);">Session: 2026</span>
              </div>
          </div>

          <!-- Main Statistics Cards -->
          <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px;">

              <div style="background: linear-gradient(135deg, #00c6ff 0%, #0072ff 100%); padding: 25px; border-radius: 12px; box-shadow: 0 8px 16px rgba(0, 114, 255, 0.2); color: white; position: relative; overflow: hidden;">
                  <div style="position: absolute; right: 15px; top: 20px; font-size: 40px; opacity: 0.2;"><i class="fa fa-building"></i></div>
                  <h4 style="margin: 0; font-size: 13px; text-transform: uppercase; letter-spacing: 1px; opacity: 0.9;">Total Departments</h4>
                  <h2 style="margin: 12px 0 0 0; font-size: 32px; font-weight: bold;">05</h2>
                  <p class="card-note">Active Academic Units</p>
              </div>

              <div style="background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%); padding: 25px; border-radius: 12px; box-shadow: 0 8px 16px rgba(56, 239, 125, 0.2); color: white; position: relative; overflow: hidden;">
                  <div style="position: absolute; right: 15px; top: 20px; font-size: 40px; opacity: 0.2;"><i class="fa fa-book"></i></div>
                  <h4 style="margin: 0; font-size: 13px; text-transform: uppercase; letter-spacing: 1px; opacity: 0.9;">Total Courses</h4>
                  <h2 style="margin: 12px 0 0 0; font-size: 32px; font-weight: bold;">24</h2>
                  <p class="card-note">Curriculum Mapped</p>
              </div>

              <div style="background: linear-gradient(135deg, #eb3349 0%, #f45c43 100%); padding: 25px; border-radius: 12px; box-shadow: 0 8px 16px rgba(235, 51, 73, 0.2); color: white; position: relative; overflow: hidden;">
                  <div style="position: absolute; right: 15px; top: 20px; font-size: 40px; opacity: 0.2;"><i class="fa fa-users"></i></div>
                  <h4 style="margin: 0; font-size: 13px; text-transform: uppercase; letter-spacing: 1px; opacity: 0.9;">Enrolled Students</h4>
                  <h2 style="margin: 12px 0 0 0; font-size: 32px; font-weight: bold;">140+</h2>
                  <p class="card-note">Active Learners</p>
              </div>

              <div style="background: linear-gradient(135deg, #f2994a 0%, #f2c94c 100%); padding: 25px; border-radius: 12px; box-shadow: 0 8px 16px rgba(242, 153, 74, 0.2); color: white; position: relative; overflow: hidden;">
                  <div style="position: absolute; right: 15px; top: 20px; font-size: 40px; opacity: 0.2;"><i class="fa fa-user-secret"></i></div>
                  <h4 style="margin: 0; font-size: 13px; text-transform: uppercase; letter-spacing: 1px; opacity: 0.9;">Faculty Members</h4>
                  <h2 style="margin: 12px 0 0 0; font-size: 32px; font-weight: bold;">12</h2>
                  <p class="card-note">Course Instructors</p>
              </div>

          </div>

          <!-- OBE Information Cards -->
          <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 20px; margin-top: 20px;">

              <div style="background: linear-gradient(135deg, #8E2DE2 0%, #4A00E0 100%); padding: 25px; border-radius: 12px; box-shadow: 0 8px 16px rgba(142, 45, 226, 0.25); color: white; position: relative; overflow: hidden;">
                  <div style="position: absolute; right: 15px; top: 20px; font-size: 40px; opacity: 0.2;"><i class="fa fa-line-chart"></i></div>
                  <h4 style="margin: 0; font-size: 13px; text-transform: uppercase; letter-spacing: 1px; opacity: 0.9;">Overall Attainment Rate</h4>
                  <h2 style="margin: 12px 0 0 0; font-size: 32px; font-weight: bold;">86.4%</h2>
                  <p class="card-note">Based on Fall 2026 CO-PO mapping</p>
              </div>

              <div style="background: linear-gradient(135deg, #ff512f 0%, #dd2476 100%); padding: 25px; border-radius: 12px; box-shadow: 0 8px 16px rgba(221, 36, 118, 0.25); color: white; position: relative; overflow: hidden;">
                  <div style="position: absolute; right: 15px; top: 20px; font-size: 40px; opacity: 0.2;"><i class="fa fa-exclamation-triangle"></i></div>
                  <h4 style="margin: 0; font-size: 13px; text-transform: uppercase; letter-spacing: 1px; opacity: 0.9;">Pending CQI Actions</h4>
                  <h2 style="margin: 12px 0 0 0; font-size: 32px; font-weight: bold;">02</h2>
                  <p class="card-note">Requires remedial action/review</p>
              </div>

              <div style="background: linear-gradient(135deg, #1d976c 0%, #0f5c8a 100%); padding: 25px; border-radius: 12px; box-shadow: 0 8px 16px rgba(29, 151, 108, 0.25); color: white; position: relative; overflow: hidden;">
                  <div style="position: absolute; right: 15px; top: 20px; font-size: 40px; opacity: 0.2;"><i class="fa fa-calendar"></i></div>
                  <h4 style="margin: 0; font-size: 13px; text-transform: uppercase; letter-spacing: 1px; opacity: 0.9;">Active Academic Session</h4>
                  <h2 style="margin: 12px 0 0 0; font-size: 32px; font-weight: bold;">Fall 2026</h2>
                  <p class="card-note">UITS Standard Curriculum</p>
              </div>

              <div style="background: linear-gradient(135deg, #f7971e 0%, #e65c00 100%); padding: 25px; border-radius: 12px; box-shadow: 0 8px 16px rgba(247, 151, 30, 0.25); color: white; position: relative; overflow: hidden;">
                  <div style="position: absolute; right: 15px; top: 20px; font-size: 40px; opacity: 0.2;"><i class="fa fa-check-circle"></i></div>
                  <h4 style="margin: 0; font-size: 13px; text-transform: uppercase; letter-spacing: 1px; opacity: 0.9;">CO vs PO Alignment</h4>
                  <h2 style="margin: 12px 0 0 0; font-size: 28px; font-weight: bold;">100% Complete</h2>
                  <p class="card-note">All mappings verified successfully</p>
              </div>

          </div>

          <!-- System Status & Notice -->
          <div style="margin-top: 25px; background: #0f1a14; border: 1px solid #1f6f43; border-left: 5px solid #2ecc71; border-radius: 10px; padding: 20px 25px; color: #d8f5e3;">
              <h4 style="margin: 0 0 8px 0; font-size: 16px; font-weight: bold; color: #2ecc71;"><i class="fa fa-info-circle"></i> System Status &amp; Notice</h4>
              <p style="margin: 0; font-size: 14px; line-height: 1.6;">
                  System Status: All Course Outcomes (COs) and Program Outcomes (POs) have been successfully mapped and verified. System performance is optimal for evaluation defense.
              </p>
          </div>

      </div>
    </div>
    <div class="admin">

    </div>
</body>
</html>