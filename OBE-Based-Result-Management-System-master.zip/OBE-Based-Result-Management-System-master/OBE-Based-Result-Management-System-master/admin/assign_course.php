<?php 
include("db.php");

function semester(){
    $current_month = date("m");
    if($current_month >= 1 && $current_month <= 4){
        return 'Spring';
    }
    if($current_month >= 5 && $current_month <= 8){
        return 'Summer';
    }
    if($current_month >= 9 && $current_month <= 12){
        return 'Fall';
    }
    return 'Spring';
}

$s = semester();
$current_year = date("Y"); 
$y = $current_year;

if(isset($_POST['insert_row'])){
    $offered_course_code = mysqli_real_escape_string($connection, $_POST['insert_row']);  
    $section = mysqli_real_escape_string($connection, $_POST['sec_no']); 
    $semester = $s;
    $year = $y;
    $errors = array();

    if ($section == ""){
        $errors['sec'] = "Please select section";
        echo '<script type="text/javascript">setTimeout(function () { swal("'.$errors['sec'].'"); },300);</script>';
    } 

    if(count($errors) == 0){
        $sql6 = "SELECT * FROM course c 
                JOIN offered_course o ON c.course_id=o.course_id 
                JOIN assigned_course a ON a.offered_course_id=o.offered_course_id 
                JOIN semester sm ON sm.semester_id=a.semester_id 
                WHERE o.year='$year' AND sm.semester='$semester' AND a.sec_no='$section' AND c.course_code='$offered_course_code'";
        
        $result6 = mysqli_query($connection, $sql6);
        if($result6 && mysqli_num_rows($result6) > 0){
            $errors['sec1'] = "This section is already assigned";
            echo '<script type="text/javascript">setTimeout(function () { swal("'.$errors['sec1'].'"); },300);</script>';
        }
    }

    if(count($errors) == 0){
        $semester_id = 1;
        $sql8 = "SELECT semester_id FROM semester WHERE semester='$semester'";
        if($result8 = mysqli_query($connection, $sql8)){
            if(mysqli_num_rows($result8) > 0){
                $row8 = mysqli_fetch_array($result8);
                $semester_id = $row8['semester_id'];
            }
        }	

        $offered_id = 0;
        $sql9 = "SELECT o.offered_course_id FROM offered_course o JOIN course c ON o.course_id=c.course_id WHERE c.course_code='$offered_course_code'";
        if($result9 = mysqli_query($connection, $sql9)){
            if(mysqli_num_rows($result9) > 0){
                $row9 = mysqli_fetch_array($result9);
                $offered_id = $row9['offered_course_id'];
            }
        }

        if($offered_id > 0){
            $sql12 = "INSERT INTO assigned_course(offered_course_id, sec_no, semester_id) VALUES('$offered_id', '$section', '$semester_id')";
            if($res12 = mysqli_query($connection, $sql12)){
                echo '<script type="text/javascript">setTimeout(function () { swal("Course section has been assigned successfully"); },300);</script>';
            }
        } else {
            echo '<script type="text/javascript">setTimeout(function () { swal("Invalid Course selection"); },300);</script>';
        }
    }
}

if(isset($_POST['delete_row'])){
    $del_id = mysqli_real_escape_string($connection, $_POST["delete_row"]);
    $sql = "DELETE FROM assigned_course WHERE assigned_course_id='$del_id'";
    if(mysqli_query($connection, $sql)){
        echo '<script type="text/javascript">setTimeout(function () { swal("Course has been deleted successfully"); },100);</script>';
    } else {
        echo "<h2>ERROR: Couldn't Delete ".mysqli_error($connection)."</h2>";
    }
} 

if(isset($_POST['search'])){
    $errors = array();
    function test_input($data){
        $data = trim($data); 
        $data = stripslashes($data); 
        $data = htmlspecialchars($data);  
        return $data;
    }
    $semester = test_input($_POST['semester']);
    $year = test_input($_POST['year']);
    $dept_name = test_input($_POST['dept_name']);

    if(empty($_POST['year'])){
        $errors['year'] = "Please enter year";
        echo '<script type="text/javascript">setTimeout(function () { swal("'.$errors['year'].'"); },300);</script>';
    } else if (!preg_match("/^[0-9]*$/", $year)) {
        $errors['year2'] = "Only numbers allowed"; 
        echo '<script type="text/javascript">setTimeout(function () { swal("'.$errors['year2'].'"); },300);</script>';
    }

    if(count($errors) == 0){
        header('Location:select_assign_course.php?value1='.$semester.'&value2='.$year.'&value3='.$dept_name);
    }
}

if(isset($_POST['edit_row'])){
    $row_id = $_POST['edit_row'];
    $flag = '2';
    header('Location:edit_offer_assign.php?value1='.$row_id.'&value2='.$flag);
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Assign Course Management - UITS</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="../css/style_2.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="../css/bootstrap.min.css">
  <script src="../js/sweetalert.min.js"></script>
  <script src="../js/jquery-3.2.1.min.js"></script>
  <script src="../js/bootstrap.min.js"></script>
  <style>
      /* ===== Page background: black ===== */
      html, body {
          background: #000000 !important;
          color: #e5e7eb;
      }

      /* ===== Top navbar (colorful) ===== */
      #nb {
          background: linear-gradient(90deg, #7c3aed 0%, #2563eb 35%, #06b6d4 70%, #10b981 100%) !important;
          border: none !important;
          border-radius: 0 !important;
          box-shadow: 0 4px 22px rgba(124, 58, 237, 0.6);
      }
      #nb .navbar-brand {
          color: #ffffff !important;
          font-weight: 700;
          font-size: 20px;
      }

      /* ===== Sidebar (colorful) ===== */
      #tbl1 {
          background: linear-gradient(180deg, #1e1b4b 0%, #312e81 45%, #0e7490 100%) !important;
          border-radius: 12px;
          box-shadow: 0 0 25px rgba(139, 92, 246, 0.55);
          padding: 15px;
      }
      #tbl1 a {
          color: #f1f5f9 !important;
          font-weight: 600;
          text-decoration: none;
          display: block;
          padding: 8px 12px;
          border-radius: 8px;
          transition: 0.2s;
      }
      #tbl1 a:hover {
          background: rgba(255, 255, 255, 0.18);
          color: #fde047 !important;
          padding-left: 18px;
      }
      #tbl1 a.active-link {
          background: linear-gradient(90deg, #ec4899, #f97316) !important;
          color: #ffffff !important;
          box-shadow: 0 4px 14px rgba(236, 72, 153, 0.6);
      }
      #tbl1 .fa-home           { color: #60a5fa; }
      #tbl1 .fa-building-o     { color: #fbbf24; }
      #tbl1 .fa-book           { color: #34d399; }
      #tbl1 .fa-bookmark-o     { color: #f472b6; }
      #tbl1 .fa-cubes          { color: #c4b5fd; }
      #tbl1 .fa-graduation-cap { color: #22d3ee; }
      #tbl1 .fa-users          { color: #fb923c; }
      #tbl1 a.active-link .fa  { color: #ffffff; }

      /* ===== Main content card (dark with colorful glow) ===== */
      #main-box {
          flex-grow: 1;
          padding: 25px;
          margin-left: 20px;
          border-radius: 14px;
          background: linear-gradient(160deg, #0f0a1f 0%, #0a1226 50%, #06201f 100%);
          border: 2px solid transparent;
          background-clip: padding-box;
          box-shadow: 0 0 0 2px #7c3aed, 0 0 30px rgba(37, 99, 235, 0.6), 0 0 60px rgba(236, 72, 153, 0.25);
      }
      #main-box h3.page-title {
          margin-top: 0;
          color: #ffffff;
          font-weight: 800;
          border-bottom: 4px solid transparent;
          border-image: linear-gradient(90deg, #ec4899, #7c3aed, #2563eb, #06b6d4, #10b981, #facc15) 1;
          padding-bottom: 10px;
          text-shadow: 0 0 14px rgba(167, 139, 250, 0.8);
      }

      /* ===== Panels ===== */
      .panel {
          border: none !important;
          border-radius: 10px !important;
          overflow: hidden;
          box-shadow: 0 4px 16px rgba(0, 0, 0, 0.6);
          background: transparent !important;
      }
      .panel-heading {
          color: #ffffff !important;
          font-weight: 700 !important;
          font-size: 15px;
          border: none !important;
          padding: 12px 16px !important;
      }
      .panel-filter .panel-heading { background: linear-gradient(90deg, #7c3aed, #ec4899) !important; }
      .panel-step1  .panel-heading { background: linear-gradient(90deg, #2563eb, #06b6d4) !important; }
      .panel-step2  .panel-heading { background: linear-gradient(90deg, #059669, #facc15) !important; }
      .panel-filter .panel-body { background: linear-gradient(135deg, #2e1065, #4c1d95); }
      .panel-step1  .panel-body { background: linear-gradient(135deg, #082f49, #155e75); }
      .panel-step2  .panel-body { background: linear-gradient(135deg, #064e3b, #166534); }
      .panel-body label { color: #fde68a; font-weight: 700; }

      /* ===== Form fields ===== */
      .form-control {
          background: #111827 !important;
          color: #ffffff !important;
          border: 2px solid #a78bfa !important;
          border-radius: 8px !important;
          height: 40px;
          font-weight: 500;
      }
      .form-control option { background: #111827; color: #ffffff; }
      .form-control::placeholder { color: #9ca3af; }
      .form-control:focus {
          border-color: #22d3ee !important;
          box-shadow: 0 0 0 3px rgba(34, 211, 238, 0.35) !important;
      }

      /* ===== Buttons ===== */
      .btn { border: none !important; border-radius: 8px !important; font-weight: 700 !important; color: #ffffff !important; }
      .btn-primary { background: linear-gradient(90deg, #ec4899, #7c3aed) !important; }
      .btn-info    { background: linear-gradient(90deg, #2563eb, #06b6d4) !important; }
      .btn-success { background: linear-gradient(90deg, #059669, #84cc16) !important; }
      .btn-warning { background: linear-gradient(90deg, #f59e0b, #f97316) !important; }
      .btn-danger  { background: linear-gradient(90deg, #e11d48, #f43f5e) !important; }
      .btn:hover   { filter: brightness(1.2); transform: translateY(-1px); box-shadow: 0 4px 14px rgba(255,255,255,0.2); }

      /* ===== Table ===== */
      .list-title {
          color: #ffffff;
          font-weight: 700;
          margin-top: 30px;
          padding-left: 12px;
          border-left: 6px solid #ec4899;
          text-shadow: 0 0 10px rgba(236, 72, 153, 0.7);
      }
      #tbl2 {
          border-radius: 10px;
          overflow: hidden;
          border: 2px solid #7c3aed !important;
          background: transparent !important;
      }
      #tbl2 thead {
          background: linear-gradient(90deg, #7c3aed, #2563eb, #06b6d4, #10b981) !important;
      }
      #tbl2 thead th {
          color: #ffffff !important;
          font-weight: 700;
          border-color: rgba(255,255,255,0.25) !important;
      }
      #tbl2 tbody tr:nth-child(odd)  td { background: #1e1b4b !important; }
      #tbl2 tbody tr:nth-child(even) td { background: #3b0a2e !important; }
      #tbl2 tbody tr:hover td { background: #713f12 !important; }
      #tbl2 tbody td {
          color: #f9fafb !important;
          vertical-align: middle !important;
          border-color: #4c1d95 !important;
      }
      #tbl2 tbody td strong { color: #22d3ee; }
  </style>
</head>
<body>
   <div id="function">
	   <div>
			<nav class="navbar navbar-default" id="nb">
			  <div class="container-fluid">
			    <div class="navbar-header">
			      <a class="navbar-brand" href="#"><i class="fa fa-tachometer"></i> UITS Admin Dashboard</a>
			    </div>
			  </div>
		  </nav>

      <div style="width:95%; margin:0px auto; display: flex;" id="nb2">
       
       <!-- UITS Sidebar -->
       <table id="tbl1" width="16%" height="565px" style="flex-shrink: 0;">
        <tr><td valign="top"><br>
          <a href="#" class="glyphicon glyphicon-user" style="font-weight: bold; color: #fde047 !important;"> UITS</a><br><br>
          <a href="admin_dashboard.php"><i class="fa fa-home"></i> Dashboard</a><br><br>
          <a href="department.php"><i class="fa fa-building-o"></i> Department</a><br><br>
          <a href="course.php"><i class="fa fa-book"></i> Course</a><br><br>
          <a href="offered_course.php"><i class="fa fa-bookmark-o"></i> Offer Course</a><br><br>
          <a href="assign_course.php" class="active-link"><i class="fa fa-tasks"></i> Assign Course</a><br><br>
          <a href="component.php"><i class="fa fa-cubes"></i> Component</a><br><br>
          <a href="history.php"><i class="fa fa-graduation-cap"></i> Student PO</a><br><br>
		  <a href="st_enrollment.php"><i class="fa fa-users"></i> Student Enrollment</a><br><br><br>
          <a href="../logout.php" class="glyphicon glyphicon-log-out" style="color: #fb7185 !important;"> Logout</a>
          </td>
        </tr>
      </table>  

	  <!-- Main Assign Course Content -->
	  <div id="main-box">
	    <h3 class="page-title">Assign Course Management</h3>
        <br>
		
		<!-- Filter Section -->
		<div class="panel panel-default panel-filter">
			<div class="panel-heading"><i class="fa fa-filter"></i> Filter Assigned Courses</div>
			<div class="panel-body">
				<form method="POST" action="">
					<div class="row">
						<div class="col-md-3">
							<label>Semester:</label>
							<select name="semester" class="form-control" required>
							<?php
								$query = "SELECT DISTINCT semester FROM semester ORDER BY semester_id";
								if($result = mysqli_query($connection, $query)){
									if(mysqli_num_rows($result) > 0){
										while ($row = mysqli_fetch_array($result)){
											echo "<option value='".$row['semester']."'>".$row['semester']."</option>";
										}
									}
								}
							?>  
							</select>
						</div>
						<div class="col-md-3">
							<label>Year:</label>
							<input type="text" name="year" class="form-control" placeholder="Ex: 2026" value="<?php echo date('Y'); ?>" required>
						</div>
						<div class="col-md-3">
							<label>Department:</label>
							<select name="dept_name" class="form-control" required>
							<?php
								$sql = "SELECT DISTINCT dept FROM dept";
								if($result = mysqli_query($connection, $sql)){
									if(mysqli_num_rows($result) > 0){
										while ($row = mysqli_fetch_array($result)){
											echo "<option value='".$row['dept']."'>".$row['dept']."</option>";
										}
									}
								}
							?>  
							</select>
						</div>
						<div class="col-md-3"><br>
							<input type="submit" name="search" class="btn btn-primary btn-block" value="Select / Filter">
						</div>
					</div>
				</form>
			</div>
		</div>

		<!-- Step 1: Choose Offered Course -->
		<div class="panel panel-default panel-step1">
			<div class="panel-heading"><i class="fa fa-bookmark"></i> Step 1: Select Offered Course</div>
			<div class="panel-body">
				<form method="POST" action="">
					<div class="row">
						<div class="col-md-8">
							<select name="offered_course_code" class="form-control" required>
								<option value="">-- Select Offered Course --</option>
								<?php	 
									$sql = "SELECT a.course_code, b.tot_sec FROM course a 
											INNER JOIN offered_course b ON a.course_id=b.course_id 
											INNER JOIN semester c ON b.semester_id=c.semester_id 
											WHERE c.semester='$s' AND b.year='$y'";
									$select = mysqli_query($connection, $sql);
									if($select && mysqli_num_rows($select) > 0) {
										while ($row = mysqli_fetch_array($select)) {
											$selected_attr = (isset($_POST['offered_course_code']) && $_POST['offered_course_code'] == $row['course_code']) ? 'selected' : '';
											echo "<option value='".$row['course_code']."' $selected_attr>".$row['course_code']." (Total Sec: ".$row['tot_sec'].")</option>";
										}
									}
								?>
							</select>
						</div>
						<div class="col-md-4">
							<button type="submit" name="set_course_code" class="btn btn-info btn-block"><i class="fa fa-arrow-right"></i> Next Step</button>
						</div>
					</div>
				</form>
			</div>
		</div>

		<!-- Step 2: Assign Section -->
		<?php if(isset($_POST['set_course_code'])): 
			$offered_course_code = mysqli_real_escape_string($connection, $_POST['offered_course_code']);
			if(!empty($offered_course_code)):
		?>
		<div class="panel panel-success panel-step2">
			<div class="panel-heading"><i class="fa fa-check-square-o"></i> Step 2: Assign Section for <?php echo htmlspecialchars($offered_course_code); ?></div>
			<div class="panel-body">
				<form method="POST" action="">
					<div class="row">
						<div class="col-md-8">
							<label>Section:</label>
							<select name="sec_no" class="form-control" required>
								<option value="">-- Select Section --</option>
								<?php	 
									$sql8 = "SELECT b.tot_sec FROM course a 
											INNER JOIN offered_course b ON a.course_id=b.course_id 
											INNER JOIN semester c ON b.semester_id=c.semester_id 
											WHERE a.course_code='$offered_course_code' AND c.semester='$s' AND b.year='$y'";
									
									if($result8 = mysqli_query($connection, $sql8)){
										if(mysqli_num_rows($result8) > 0){
											$row8 = mysqli_fetch_array($result8);
											$total_sec = $row8['tot_sec'];
											for($i=1; $i<=$total_sec; $i++){
												echo "<option value='$i'>Section $i</option>";
											}
										}
									}
								?>
							</select>
						</div>
						<div class="col-md-4"><br>
							<button type="submit" name="insert_row" value="<?php echo htmlspecialchars($offered_course_code); ?>" class="btn btn-success btn-block"><i class="fa fa-plus-circle"></i> Confirm Assign</button>
						</div>
					</div>
				</form>
			</div>
		</div>
		<?php endif; endif; ?>

		<!-- Assigned Course List Table -->
		<h4 class="list-title">Assigned Courses List (<?php echo $s.' '.$y; ?>)</h4>
		<form method="POST" action="">
			<div class="table-responsive">
				<table id="tbl2" class="table table-bordered table-striped" width="100%">
					<thead>
						<tr>
							<th>Offered Course Code</th>
							<th>Section</th>
							<th colspan="2" style="text-align: center;">Action</th>
						</tr>
					</thead>
					<tbody>
						<?php 
							$sql1 = "SELECT a.assigned_course_id, c.course_code, a.sec_no 
									FROM course c 
									JOIN offered_course o ON c.course_id=o.course_id 
									JOIN assigned_course a ON o.offered_course_id=a.offered_course_id 
									JOIN semester sm ON a.semester_id=sm.semester_id  
									WHERE sm.semester='$s' AND o.year='$y' 
									ORDER BY c.course_code, a.sec_no";

							if($result2 = mysqli_query($connection, $sql1)){
								if(mysqli_num_rows($result2) > 0){
									while($row = mysqli_fetch_array($result2)){
										echo "<tr>";
										echo "<td><strong>".$row["course_code"]."</strong></td>";
										echo "<td>Section ".$row["sec_no"]."</td>";		
						?>
							<td style="text-align: center;">
								<button type="submit" name="edit_row" class="btn btn-warning btn-sm" value="<?php echo $row['assigned_course_id']; ?>"><i class="fa fa-edit"></i></button>
							</td>
							<td style="text-align: center;">
								<button type="submit" name="delete_row" class="btn btn-danger btn-sm" value="<?php echo $row['assigned_course_id']; ?>" onclick="return confirm('Are you sure to delete?')"><i class="fa fa-trash"></i></button>
							</td>
						</tr>
						<?php
									}
								} else {
									echo "<tr><td colspan='4' class='text-center'>No courses assigned yet for $s $y.</td></tr>";
								}
							}
						?>
					</tbody>
				</table>
			</div>
		</form>
	   </div>

	</div>
  </div>
</body>
</html>