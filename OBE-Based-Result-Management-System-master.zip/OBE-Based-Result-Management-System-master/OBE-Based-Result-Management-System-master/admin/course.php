<?php
// ---------- 1. DB connection ----------
$db_paths = [
    __DIR__ . '/../db.php',
    __DIR__ . '/db.php',
    __DIR__ . '/../config/db.php',
    __DIR__ . '/../includes/db.php',
];
$db_found = false;
foreach ($db_paths as $path) {
    if (file_exists($path)) {
        require_once $path;
        $db_found = true;
        break;
    }
}
if (!$db_found) {
    die("db.php file paoa jayni.");
}

if (!isset($conn) || !($conn instanceof mysqli)) {
    foreach (['con', 'db', 'mysqli', 'link', 'connection', 'connect', 'dbh'] as $name) {
        if (isset($$name) && $$name instanceof mysqli) {
            $conn = $$name;
            break;
        }
    }
}
if (!isset($conn) || !($conn instanceof mysqli)) {
    die("db.php te mysqli connection paoa jayni.");
}

// ---------- 2. Add / Edit / Delete ----------
$msg  = '';
$type = 'success';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    try {
        if ($action === 'add') {
            $code    = trim($_POST['course_code'] ?? '');
            $name    = trim($_POST['course_name'] ?? '');
            $credits = (float)($_POST['credits'] ?? 0);

            if ($code === '' || $name === '') {
                throw new Exception("Course code ar name dewa lagbe.");
            }
            $stmt = mysqli_prepare($conn, "INSERT INTO courses (course_code, course_name, credits) VALUES (?, ?, ?)");
            mysqli_stmt_bind_param($stmt, "ssd", $code, $name, $credits);
            mysqli_stmt_execute($stmt);
            $msg = "Course successfully add hoyeche.";

        } elseif ($action === 'edit') {
            $id      = (int)($_POST['id'] ?? 0);
            $code    = trim($_POST['course_code'] ?? '');
            $name    = trim($_POST['course_name'] ?? '');
            $credits = (float)($_POST['credits'] ?? 0);

            if ($id <= 0 || $code === '' || $name === '') {
                throw new Exception("Shob field thikmoto dewa lagbe.");
            }
            $stmt = mysqli_prepare($conn, "UPDATE courses SET course_code = ?, course_name = ?, credits = ? WHERE id = ?");
            mysqli_stmt_bind_param($stmt, "ssdi", $code, $name, $credits, $id);
            mysqli_stmt_execute($stmt);
            $msg = "Course successfully update hoyeche.";

        } elseif ($action === 'delete') {
            $id = (int)($_POST['id'] ?? 0);
            if ($id <= 0) {
                throw new Exception("Invalid course.");
            }
            $stmt = mysqli_prepare($conn, "DELETE FROM courses WHERE id = ?");
            mysqli_stmt_bind_param($stmt, "i", $id);
            mysqli_stmt_execute($stmt);
            $msg = "Course delete hoyeche.";
        }
    } catch (Throwable $e) {
        $type = 'danger';
        $msg  = "Error: " . $e->getMessage();
    }

    // Refresh korle abar submit na hoy, tai redirect
    header("Location: " . strtok($_SERVER['REQUEST_URI'], '?') . "?type=" . $type . "&msg=" . urlencode($msg));
    exit;
}

if (isset($_GET['msg'])) {
    $msg  = $_GET['msg'];
    $type = ($_GET['type'] ?? '') === 'danger' ? 'danger' : 'success';
}

// ---------- 3. Data ----------
$result = mysqli_query($conn, "SELECT id, course_code, course_name, credits FROM courses ORDER BY id ASC");
$colors = ['#ff6b6b', '#feca57', '#1dd1a1', '#54a0ff', '#c56cf0', '#ff9f43'];

// ---------- 4. Sidebar (project-er sidebar file thakle auto include hobe) ----------
$sidebar_paths = [
    __DIR__ . '/sidebar.php',
    __DIR__ . '/includes/sidebar.php',
    __DIR__ . '/../includes/sidebar.php',
    __DIR__ . '/navbar.php',
    __DIR__ . '/includes/navbar.php',
];
$sidebar_file = '';
foreach ($sidebar_paths as $p) {
    if (file_exists($p)) {
        $sidebar_file = $p;
        break;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Manage Courses</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <style>
        body { background: #000; min-height: 100vh; color: #fff; }
        .main-card {
            background: linear-gradient(135deg, #1e1e3f, #2d1b4e, #0f3460);
            border: 2px solid #c56cf0;
            border-radius: 16px;
            box-shadow: 0 0 25px rgba(197, 108, 240, 0.5);
            overflow: hidden;
        }
        .card-header-colorful {
            background: linear-gradient(90deg, #ff6b6b, #feca57, #1dd1a1, #54a0ff, #c56cf0);
            color: #000;
            font-weight: bold;
            padding: 18px;
        }
        .table { color: #fff; margin-bottom: 0; }
        .table thead th { background: linear-gradient(90deg, #6c5ce7, #a29bfe); color: #fff; border: none; }
        .table td, .table th { border-color: rgba(255,255,255,0.15); vertical-align: middle; }
        .table tbody tr:hover { background: rgba(255,255,255,0.1); }
        .badge-credit { font-size: 14px; padding: 6px 12px; border-radius: 20px; color: #000; font-weight: bold; }
        .modal-content { background: #1e1e3f; color: #fff; border: 2px solid #c56cf0; }
        .modal-header, .modal-footer { border-color: rgba(255,255,255,0.15); }
        .modal .close { color: #fff; }
        .form-control { background: #2d2d5a; color: #fff; border-color: #6c5ce7; }
        .form-control:focus { background: #2d2d5a; color: #fff; }
    </style>
</head>
<body>

<div class="d-flex">

    <?php if ($sidebar_file) { include $sidebar_file; } ?>

    <div class="flex-grow-1 p-3" style="min-width:0;">
        <div class="container-fluid my-4">

            <?php if ($msg !== '') { ?>
                <div class="alert alert-<?php echo $type; ?> alert-dismissible fade show">
                    <?php echo htmlspecialchars($msg); ?>
                    <button type="button" class="close" data-dismiss="alert">&times;</button>
                </div>
            <?php } ?>

            <div class="main-card">
                <div class="card-header-colorful d-flex justify-content-between align-items-center">
                    <h4 class="mb-0">📚 Course Management</h4>
                    <button class="btn btn-dark btn-sm" data-toggle="modal" data-target="#addModal">+ Add Course</button>
                </div>
                <div class="p-3">
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Course Code</th>
                                    <th>Course Name</th>
                                    <th>Credits</th>
                                    <th style="width:160px;">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                if ($result && mysqli_num_rows($result) > 0) {
                                    $i = 0;
                                    while ($row = mysqli_fetch_assoc($result)) {
                                        $color = $colors[$i % count($colors)];
                                        $i++;
                                ?>
                                    <tr>
                                        <td style="color:<?php echo $color; ?>; font-weight:bold;">
                                            <?php echo htmlspecialchars($row['id']); ?>
                                        </td>
                                        <td><?php echo htmlspecialchars($row['course_code']); ?></td>
                                        <td><?php echo htmlspecialchars($row['course_name']); ?></td>
                                        <td>
                                            <span class="badge-credit" style="background:<?php echo $color; ?>;">
                                                <?php echo htmlspecialchars($row['credits']); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <button type="button" class="btn btn-warning btn-sm btn-edit"
                                                data-id="<?php echo (int)$row['id']; ?>"
                                                data-code="<?php echo htmlspecialchars($row['course_code'], ENT_QUOTES); ?>"
                                                data-name="<?php echo htmlspecialchars($row['course_name'], ENT_QUOTES); ?>"
                                                data-credits="<?php echo htmlspecialchars($row['credits'], ENT_QUOTES); ?>">
                                                Edit
                                            </button>
                                            <form method="post" class="d-inline"
                                                  onsubmit="return confirm('Ei course ta delete korte chao?');">
                                                <input type="hidden" name="action" value="delete">
                                                <input type="hidden" name="id" value="<?php echo (int)$row['id']; ?>">
                                                <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php
                                    }
                                } else {
                                    echo "<tr><td colspan='5' class='text-center'>No courses found</td></tr>";
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<!-- Add Modal -->
<div class="modal fade" id="addModal" tabindex="-1">
    <div class="modal-dialog">
        <form method="post" class="modal-content">
            <input type="hidden" name="action" value="add">
            <div class="modal-header">
                <h5 class="modal-title">Add Course</h5>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <label>Course Code</label>
                    <input type="text" name="course_code" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Course Name</label>
                    <input type="text" name="course_name" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Credits</label>
                    <input type="number" name="credits" class="form-control" step="0.5" min="0" required>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-success">Save</button>
            </div>
        </form>
    </div>
</div>

<!-- Edit Modal -->
<div class="modal fade" id="editModal" tabindex="-1">
    <div class="modal-dialog">
        <form method="post" class="modal-content">
            <input type="hidden" name="action" value="edit">
            <input type="hidden" name="id" id="edit_id">
            <div class="modal-header">
                <h5 class="modal-title">Edit Course</h5>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <label>Course Code</label>
                    <input type="text" name="course_code" id="edit_code" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Course Name</label>
                    <input type="text" name="course_name" id="edit_name" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Credits</label>
                    <input type="number" name="credits" id="edit_credits" class="form-control" step="0.5" min="0" required>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-primary">Update</button>
            </div>
        </form>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
    $(document).on('click', '.btn-edit', function () {
        $('#edit_id').val($(this).data('id'));
        $('#edit_code').val($(this).data('code'));
        $('#edit_name').val($(this).data('name'));
        $('#edit_credits').val($(this).data('credits'));
        $('#editModal').modal('show');
    });
</script>

</body>
</html>