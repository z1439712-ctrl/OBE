<?php 
include("db.php");
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$username = isset($_SESSION['username']) ? $_SESSION['username'] : 'Admin';

// Handle Student Enrollment Submission
if(isset($_POST['enroll_student'])){
    $s_id = mysqli_real_escape_string($connection, $_POST['s_id']);
    $name = mysqli_real_escape_string($connection, $_POST['name']);
    $course_code = mysqli_real_escape_string($connection, $_POST['course_code']);
    $sec_no = mysqli_real_escape_string($connection, $_POST['sec_no']);
    $semester = mysqli_real_escape_string($connection, $_POST['semester']);
    $year = mysqli_real_escape_string($connection, $_POST['year']);

    if(!empty($s_id) && !empty($name)){
        $ins_sql = "INSERT INTO student (s_id, name, course_code, sec_no, semester, year, grade) VALUES ('$s_id', '$name', '$course_code', '$sec_no', '$semester', '$year', 'A+')";
        if(mysqli_query($connection, $ins_sql)){
            echo '<script type="text/javascript">setTimeout(function () { swal("Success!", "Student enrolled successfully!", "success"); },300);</script>';
        } else {
            echo '<script type="text/javascript">setTimeout(function () { swal("Error!", "Enrollment failed!", "error"); },300);</script>';
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Student Enrollment - UITS OBE System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="../css/style_2.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="../css/bootstrap.min.css">
  <script src="../js/sweetalert.min.js"></script>
  <script src="../js/jquery-3.2.1.min.js"></script>
  <script src="../js/bootstrap.min.js"></script>
  <style>
      /* ===== Palette: black base, grey surfaces, one blue accent ===== */
      :root {
          --bg: #000000;
          --surface: #111317;
          --surface-2: #181b21;
          --border: #262a33;
          --text: #e5e7eb;
          --muted: #9ca3af;
          --accent: #3b82f6;
          --accent-hover: #2563eb;
      }

      html, body {
          background: var(--bg) !important;
          background-color: var(--bg) !important;
          color: var(--text);
          font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      }
      #function, #nb2 { background: transparent !important; }

      /* ===== Top navbar ===== */
      #nb {
          background: #0b0d10 !important;
          border: none !important;
          border-bottom: 1px solid var(--border) !important;
          border-radius: 0 !important;
          margin-bottom: 0 !important;
      }

      /* ===== Sidebar ===== */
      #tbl1 {
          background: var(--surface) !important;
          border: 1px solid var(--border);
          padding: 15px;
          border-radius: 8px;
      }
      #tbl1 hr { border-top: 1px solid var(--border); }
      #tbl1 a {
          color: var(--muted) !important;
          font-weight: 500;
          text-decoration: none;
          display: block;
          padding: 9px 12px;
          border-radius: 6px;
          border-left: 3px solid transparent;
          transition: 0.2s;
      }
      #tbl1 a i { color: var(--muted); margin-right: 6px; }
      #tbl1 a:hover {
          background: var(--surface-2);
          color: #ffffff !important;
      }
      #tbl1 a:hover i { color: #ffffff; }
      #tbl1 a.active-link {
          background: rgba(59, 130, 246, 0.15) !important;
          color: #ffffff !important;
          border-left-color: var(--accent);
      }
      #tbl1 a.active-link i { color: var(--accent); }

      /* ===== Header bar ===== */
      .top-bar {
          background: var(--surface);
          border: 1px solid var(--border);
          padding: 15px 20px;
          border-radius: 8px;
          margin-bottom: 20px;
          display: flex;
          justify-content: space-between;
          align-items: center;
      }
      .top-bar h3 {
          margin: 0;
          font-weight: 600;
          color: #ffffff;
      }
      .top-bar h3 i { color: var(--accent); }
      .session-badge {
          background: var(--surface-2) !important;
          border: 1px solid var(--border);
          color: var(--text) !important;
          font-size: 13px;
          padding: 8px 12px;
          font-weight: 500;
      }

      /* ===== Cards ===== */
      .card-custom {
          background: var(--surface);
          border: 1px solid var(--border);
          border-radius: 8px;
          padding: 25px;
          margin-bottom: 25px;
          color: var(--text);
      }
      .card-custom h4 {
          margin-top: 0;
          font-weight: 600;
          color: #ffffff;
          padding-bottom: 12px;
          border-bottom: 1px solid var(--border);
      }
      .card-custom h4 i { color: var(--accent); }

      /* ===== Form ===== */
      .card-custom label {
          font-size: 13px;
          font-weight: 500;
          color: var(--muted);
      }
      .card-custom .form-control {
          background: #0a0b0d;
          border: 1px solid var(--border);
          color: #ffffff;
          box-shadow: none;
      }
      .card-custom .form-control::placeholder { color: #6b7280; }
      .card-custom .form-control:focus {
          border-color: var(--accent);
          box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.25);
      }
      .btn-confirm {
          background: var(--accent);
          border: none;
          color: #ffffff;
          font-weight: 600;
          transition: 0.2s;
      }
      .btn-confirm:hover, .btn-confirm:focus {
          background: var(--accent-hover);
          color: #ffffff;
      }

      /* ===== Table ===== */
      .table-responsive { border: none; }
      .tbl-dark {
          background: transparent;
          color: var(--text);
          border: 1px solid var(--border) !important;
      }
      .tbl-dark > thead > tr > th {
          background: var(--surface-2) !important;
          color: #ffffff !important;
          border-color: var(--border) !important;
          font-weight: 600;
      }
      .tbl-dark > tbody > tr > td {
          border-color: var(--border) !important;
          color: var(--text);
          background: transparent !important;
      }
      .tbl-dark > tbody > tr:nth-child(even) > td { background: rgba(255, 255, 255, 0.025) !important; }
      .tbl-dark > tbody > tr:hover > td { background: rgba(59, 130, 246, 0.10) !important; }
      .sid { color: #ffffff; font-weight: 600; }
      .sname { color: var(--text); }

      /* course code badge: one uniform style */
      .cc {
          display: inline-block;
          padding: 3px 9px;
          border-radius: 4px;
          font-size: 12px;
          font-weight: 600;
          color: #93c5fd;
          background: rgba(59, 130, 246, 0.15);
          border: 1px solid rgba(59, 130, 246, 0.35);
      }
      .sem-tag { color: var(--muted); font-weight: 500; }
      .empty-msg { color: var(--muted) !important; }
  </style>
</head>
<body>
  <div id="function">
    <nav class="navbar navbar-default" id="nb">
      <div class="container-fluid">
        <div class="navbar-header">
          <a class="navbar-brand" href="#" style="color: #ffffff !important; font-weight: 600; font-size: 20px;"><i class="fa fa-graduation-cap" style="color: #3b82f6;"></i> UITS OBE Management System</a>
        </div>
      </div>
    </nav>

    <div style="width:98%; margin:15px auto; display: flex;" id="nb2">

      <!-- UITS Sidebar -->
      <table id="tbl1" width="18%" height="600px" style="flex-shrink: 0;">
        <tr><td valign="top"><br>
          <a href="#" class="glyphicon glyphicon-user" style="font-weight: 600; color: #ffffff !important; font-size: 15px;"> UITS Admin</a><br><hr>
          <a href="admin_dashboard.php"><i class="fa fa-home"></i> Dashboard</a><br>
          <a href="department.php"><i class="fa fa-building-o"></i> Department</a><br>
          <a href="course.php"><i class="fa fa-book"></i> Course</a><br>
          <a href="offered_course.php"><i class="fa fa-bookmark-o"></i> Offer Course</a><br>
          <a href="assign_course.php"><i class="fa fa-tasks"></i> Assign Course</a><br>
          <a href="component.php"><i class="fa fa-cubes"></i> Component</a><br>
          <a href="history.php"><i class="fa fa-line-chart"></i> Student PO & History</a><br>
          <a href="st_enrollment.php" class="active-link"><i class="fa fa-users"></i> Student Enrollment</a><br><br><hr>
          <a href="../logout.php" class="glyphicon glyphicon-log-out" style="color: #f87171 !important;"> Logout</a>
        </td></tr>
      </table>

      <!-- Main Content -->
      <div style="flex-grow: 1; padding: 0 25px; margin-left: 20px;">

        <div class="top-bar">
          <h3><i class="fa fa-users"></i> Student Manual Enrollment</h3>
          <span class="badge session-badge">Session: Fall 2026</span>
        </div>

        <!-- Enrollment Form -->
        <div class="card-custom">
          <h4><i class="fa fa-user-plus"></i> Enroll Student to Course</h4>
          <br>
          <form method="POST" action="">
            <div class="row">
              <div class="col-md-3">
                <label>Student ID:</label>
                <input type="text" name="s_id" class="form-control" placeholder="Ex: 99" required>
              </div>
              <div class="col-md-4">
                <label>Student Name:</label>
                <input type="text" name="name" class="form-control" placeholder="Ex: Zahid" required>
              </div>
              <div class="col-md-3">
                <label>Course Code:</label>
                <input type="text" name="course_code" class="form-control" placeholder="Ex: CSE416" required>
              </div>
              <div class="col-md-2">
                <label>Section:</label>
                <input type="text" name="sec_no" class="form-control" value="1" placeholder="Ex: 1" required>
              </div>
            </div>
            <br>
            <div class="row">
              <div class="col-md-3">
                <label>Semester:</label>
                <input type="text" name="semester" class="form-control" value="Fall" required>
              </div>
              <div class="col-md-3">
                <label>Year:</label>
                <input type="text" name="year" class="form-control" value="2026" required>
              </div>
              <div class="col-md-4"><br>
                <button type="submit" name="enroll_student" class="btn btn-confirm btn-block"><i class="fa fa-check-circle"></i> Confirm Enrollment</button>
              </div>
            </div>
          </form>
        </div>

        <!-- Enrolled Students Table List -->
        <div class="card-custom">
          <h4><i class="fa fa-list"></i> Enrolled Students List</h4>
          <div class="table-responsive" style="margin-top: 15px;">
            <table class="table table-bordered tbl-dark" style="margin-bottom: 0;">
              <thead>
                <tr>
                  <th>SL</th>
                  <th>Student ID</th>
                  <th>Name</th>
                  <th>Course Code</th>
                  <th>Section</th>
                  <th>Semester & Year</th>
                </tr>
              </thead>
              <tbody>
                <?php
                $res = mysqli_query($connection, "SELECT * FROM student ORDER BY student_id DESC");
                if($res && mysqli_num_rows($res) > 0){
                    $sl = 1;
                    while($r = mysqli_fetch_assoc($res)){
                        $section_display = (!empty($r['sec_no']) && $r['sec_no'] != '0') ? $r['sec_no'] : '1';
                        echo "<tr>";
                        echo "<td>".$sl."</td>";
                        echo "<td class='sid'>".htmlspecialchars($r['s_id'])."</td>";
                        echo "<td class='sname'>".htmlspecialchars($r['name'])."</td>";
                        echo "<td><span class='cc'>".htmlspecialchars($r['course_code'])."</span></td>";
                        echo "<td>".htmlspecialchars($section_display)."</td>";
                        echo "<td class='sem-tag'>".htmlspecialchars($r['semester'])." ".htmlspecialchars($r['year'])."</td>";
                        echo "</tr>";
                        $sl++;
                    }
                } else {
                    echo "<tr><td colspan='6' class='text-center empty-msg'>No enrolled students found.</td></tr>";
                }
                ?>
              </tbody>
            </table>
          </div>
        </div>

      </div>
    </div>
  </div>
</body>
</html>