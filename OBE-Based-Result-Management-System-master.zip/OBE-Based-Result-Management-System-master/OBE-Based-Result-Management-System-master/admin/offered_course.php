<?php include("db.php");

	$current_month = date("m");
	$current_year = date("Y"); 
	$flag = 0;
	
	if($current_month>=1 && $current_month<=4){
		$s='Spring';
		$y=$current_year;
		$sql1 = "SELECT a.course_code as course_code,b.tot_sec as total_section 
				FROM course a INNER JOIN offered_course b ON a.course_id=b.course_id 
				INNER JOIN semester c ON b.semester_id=c.semester_id 
				WHERE c.semester='$s' AND b.year='$y'";
		$flag = 1; 
	}	
	if($current_month>=5 && $current_month<=8){
		$s='Summer';
		$y=$current_year;
		$sql2 = "SELECT a.course_code as course_code,b.tot_sec as total_section 
				FROM course a INNER JOIN offered_course b ON a.course_id=b.course_id 
				INNER JOIN semester c ON b.semester_id=c.semester_id 
				WHERE c.semester='$s' AND b.year='$y'";
		$flag = 2; 
	}
	if($current_month>=9 && $current_month<=12){
		$s='Fall';
		$y=$current_year;
		$sql3 = "SELECT a.course_code as course_code,b.tot_sec as total_section 
				FROM course a INNER JOIN offered_course b ON a.course_id=b.course_id 
				INNER JOIN semester c ON b.semester_id=c.semester_id 
				WHERE c.semester='$s' AND b.year='$y'";
		$flag = 3; 
	}	
	if(($flag==1 && ($result=mysqli_query($connection,$sql1)))||
		($flag==2 && ($result=mysqli_query($connection,$sql2)))||
		($flag==3 && ($result=mysqli_query($connection,$sql3)))){
		if($result && mysqli_num_rows($result)>0){
			$total=mysqli_num_rows($result);
			$semseter=$s;
			$year=$y;
		}
	}


	if(isset($_POST['insert_row'])){
		$offered_course_code=mysqli_real_escape_string($connection, $_POST['offered_course_code']);  
		$section=mysqli_real_escape_string($connection, $_POST['sec_no']); 
		$semester=$s;
		$year=$y;
		$errors=array();
		if($offered_course_code=="" && $section ==""){
			$errors['off_course']="Please enter offer course code and Section";
			echo '<script type="text/javascript">'; 
            echo 'setTimeout(function () { swal("'.$errors['off_course'].'");';
			echo '},300);</script>';
		}
		else if($offered_course_code==""){
			$errors['off_course2']="Please select offered course code";
			echo '<script type="text/javascript">'; 
            echo 'setTimeout(function () { swal("'.$errors['off_course2'].'");';
			echo '},300);</script>';
		} 
		else if ($section==""){
			$errors['sec']="Please enter total section";
			echo '<script type="text/javascript">'; 
            echo 'setTimeout(function () { swal("'.$errors['sec'].'");';
			echo '},300);</script>';
		} 

		if(count($errors)==0){
			$sql1="SELECT course_id FROM course WHERE course_code='$offered_course_code'";
			if($result1=mysqli_query($connection,$sql1)){
				if(mysqli_num_rows($result1)>0){
					$row1 = mysqli_fetch_array($result1);
					$course_id=$row1['course_id'];
				}
			}
			
			$sql7="SELECT semester_id FROM semester WHERE semester='$semester'";
			if($result7=mysqli_query($connection,$sql7)){
				if(mysqli_num_rows($result7)>0){
					$row7 = mysqli_fetch_array($result7);
					$semester_id=$row7['semester_id'];
				}
			}

			if(isset($course_id) && isset($semester_id)){
				$sql = "SELECT * FROM offered_course WHERE course_id='$course_id' AND semester_id='$semester_id' AND year='$year'";
				if($select = mysqli_query($connection,$sql)){
					if(mysqli_num_rows($select) > 0){
						echo '<script type="text/javascript">'; 
						echo 'setTimeout(function () { swal("Course already exist"); },100);</script>';
					} else {
						$sql1 = "INSERT INTO offered_course(course_id,semester_id,year,tot_sec) VALUES('$course_id','$semester_id','$year','$section')";
						if($ins=mysqli_query($connection,$sql1)){
							echo '<script type="text/javascript">'; 
							echo 'setTimeout(function () { swal("Course has been offered successfully"); },300);</script>';
						}
					}
				}
			}
		}
	}

	if(isset($_POST['delete_row'])){ 
		$del_id = mysqli_real_escape_string($connection, $_POST["delete_row"]);
		$sql = "DELETE FROM offered_course WHERE offered_course_id='$del_id'";
		if(mysqli_query($connection,$sql)){
			echo '<script type="text/javascript">'; 
			echo 'setTimeout(function () { swal("Course has been deleted successfully"); },100);</script>';
		}
	} 

	if(isset($_POST['search'])){
		$errors=array();
		function test_input($data){
			$data = trim($data); 
			$data = stripslashes($data); 
			$data = htmlspecialchars($data);  
			return $data;
		}	
		$semester=mysqli_real_escape_string($connection, $_POST['semester']);
		$semester=test_input($semester);
		$year=mysqli_real_escape_string($connection, $_POST['year']);
		$year=test_input($year);
		$dept_name=mysqli_real_escape_string($connection, $_POST['dept_name']);
		$dept_name=test_input($dept_name);

		if(empty($_POST['year'])){
	        $errors['year']="Please enter year";
			echo '<script type="text/javascript">'; 
            echo 'setTimeout(function () { swal("'.$errors['year'].'");';
			echo '},300);</script>';
		} else if (!preg_match("/^[0-9]*$/",$year)) {
			$errors['year2']= "Only number allowed"; 
			echo '<script type="text/javascript">'; 
            echo 'setTimeout(function () { swal("'.$errors['year2'].'");';
            echo '},300);</script>';
		}

		if(count($errors)==0){
			header('Location:select_offered_course.php?value1='.$semester.'&value2='.$year.'&value3='.$dept_name);
		}
	}

	if(isset($_POST['edit_row'])){
		$row_id=$_POST['edit_row'];
		$flag='1';
		header('Location:edit_offer_assign.php?value1='.$row_id.'&value2='.$flag);
	}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Offer Course Management - UITS</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="../css/style_2.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="../css/bootstrap.min.css">
  <script src="../js/sweetalert.min.js"></script>
  <script src="../js/jquery-3.2.1.min.js"></script>
  <script src="../js/bootstrap.min.js"></script>
  <style>
      /* ===== Black page background ===== */
      html, body { background: #000000 !important; min-height: 100vh; color: #e8e8f0; }
      #function, #nb2 { background: transparent !important; }

      /* ===== Colorful sidebar ===== */
      #tbl1 {
          background: #0d0d14 !important;
          border: 1px solid #23233a;
          border-radius: 10px;
          box-shadow: 0 0 18px rgba(106, 90, 255, 0.25);
          padding: 15px;
      }
      #tbl1 a {
          color: #cfd3ff !important;
          font-weight: 600;
          text-decoration: none;
          display: block;
          padding: 8px 12px;
          border-radius: 6px;
          transition: 0.25s;
      }
      #tbl1 a:hover {
          background: linear-gradient(90deg, #7f5af0, #2cb1ff);
          color: #ffffff !important;
          padding-left: 18px;
      }
      #tbl1 a.active-link {
          background: linear-gradient(90deg, #ff4e92, #ff9a3c);
          color: #ffffff !important;
          box-shadow: 0 0 12px rgba(255, 78, 146, 0.5);
      }
      #tbl1 a.logout-link { color: #ff5f6d !important; }
      #tbl1 a.logout-link:hover { background: linear-gradient(90deg, #ff5f6d, #ffc371); color:#fff !important; }

      /* ===== Main content card ===== */
      .main-card {
          flex-grow: 1;
          padding: 25px;
          margin-left: 20px;
          border-radius: 12px;
          background: linear-gradient(145deg, #12121c 0%, #1a1130 100%);
          border: 1px solid #2a2a45;
          box-shadow: 0 0 25px rgba(44, 177, 255, 0.18);
      }
      .main-card h3 {
          margin-top: 0;
          padding-bottom: 10px;
          font-weight: 700;
          color: #fff;
          border-bottom: 3px solid transparent;
          border-image: linear-gradient(90deg, #ff4e92, #ff9a3c, #2cb1ff, #7f5af0) 1;
      }

      /* ===== Filter panel ===== */
      .panel-default { background: transparent; border: 1px solid #2d2d4d; border-radius: 10px; overflow: hidden; }
      .panel-default > .panel-heading {
          background: linear-gradient(90deg, #7f5af0, #2cb1ff) !important;
          color: #fff !important;
          border: none;
          font-weight: bold;
      }
      .panel-body { background: #101019; }
      label { color: #ffd166; }

      /* ===== Inputs ===== */
      .form-control {
          background: #1b1b2b;
          color: #fff;
          border: 1px solid #3a3a5c;
      }
      .form-control:focus {
          border-color: #2cb1ff;
          box-shadow: 0 0 8px rgba(44, 177, 255, 0.6);
          background: #20203a;
          color: #fff;
      }
      .form-control::placeholder { color: #8a8aa8; }
      select.form-control option { background: #1b1b2b; color: #fff; }

      /* ===== Table ===== */
      #tbl2 { background: #101019; color: #e8e8f0; border: 1px solid #2d2d4d; }
      #tbl2 thead { background: linear-gradient(90deg, #ff4e92, #7f5af0, #2cb1ff) !important; color: #fff; }
      #tbl2 > thead > tr > th { border-color: #2d2d4d; }
      #tbl2 > tbody > tr > td { border-color: #2d2d4d; vertical-align: middle; }
      #tbl2.table-striped > tbody > tr:nth-of-type(odd) { background: #14142a; }
      #tbl2.table-striped > tbody > tr:nth-of-type(even) { background: #191933; }
      #tbl2 > tbody > tr:hover { background: #252552 !important; }
      #tbl2 strong { color: #5eead4; }

      /* ===== Colorful buttons ===== */
      .btn { border: none; color: #fff; transition: 0.2s; }
      .btn:hover { transform: translateY(-1px); color: #fff; }
      .btn-primary { background: linear-gradient(90deg, #7f5af0, #2cb1ff); }
      .btn-success { background: linear-gradient(90deg, #11998e, #38ef7d); }
      .btn-warning { background: linear-gradient(90deg, #f7971e, #ffd200); color: #222; }
      .btn-danger  { background: linear-gradient(90deg, #ff416c, #ff4b2b); }
      .btn-primary:hover { box-shadow: 0 0 12px #2cb1ff; background: linear-gradient(90deg, #7f5af0, #2cb1ff); }
      .btn-success:hover { box-shadow: 0 0 12px #38ef7d; background: linear-gradient(90deg, #11998e, #38ef7d); }
      .btn-warning:hover { box-shadow: 0 0 12px #ffd200; background: linear-gradient(90deg, #f7971e, #ffd200); color:#222; }
      .btn-danger:hover  { box-shadow: 0 0 12px #ff416c; background: linear-gradient(90deg, #ff416c, #ff4b2b); }
  </style>
</head>
<body>
   <div id="function">
	   <div>
			<nav class="navbar navbar-default" id="nb" style="background: linear-gradient(90deg, #ff4e92 0%, #7f5af0 50%, #2cb1ff 100%); border: none; border-radius: 0;">
			  <div class="container-fluid">
			    <div class="navbar-header">
			      <a class="navbar-brand" href="#" style="color: #ffffff !important; font-weight: bold; font-size: 20px;"><i class="fa fa-tachometer"></i> UITS Admin Dashboard</a>
			    </div>
			  </div>
		  </nav>

      <div style="width:95%; margin:20px auto 0; display: flex;" id="nb2">
       
       <!-- UITS Sidebar -->
       <table id="tbl1" width="16%" height="565px" style="flex-shrink: 0;">
        <tr><td valign="top"><br>
          <a href="#" class="glyphicon glyphicon-user" style="font-weight: bold; color: #2cb1ff !important;"> UITS</a><br><br>
          <a href="admin_dashboard.php"><i class="fa fa-home"></i> Dashboard</a><br><br>
          <a href="department.php"><i class="fa fa-building-o"></i> Department</a><br><br>
          <a href="course.php"><i class="fa fa-book"></i> Course</a><br><br>
          <a href="offered_course.php" class="active-link"><i class="fa fa-bookmark-o"></i> Offer Course</a><br><br>
          <a href="assign_course.php"><i class="fa fa-tasks"></i> Assign Course</a><br><br>
          <a href="component.php"><i class="fa fa-cubes"></i> Component</a><br><br>
          <a href="history.php"><i class="fa fa-graduation-cap"></i> Student PO</a><br><br>
		  <a href="st_enrollment.php"><i class="fa fa-users"></i> Student Enrollment</a><br><br><br>
          <a href="../logout.php" class="glyphicon glyphicon-log-out logout-link"> Logout</a>
          </td>
        </tr>
      </table>  

	  <!-- Main Offered Course Content -->
	  <div class="main-card">
	    <h3>Offered Course Management</h3>
        <br>
		
		<!-- Search Offered Course -->
		<div class="panel panel-default">
			<div class="panel-heading">Filter Offered Courses</div>
			<div class="panel-body">
				<form method="POST" action="">
					<div class="row">
						<div class="col-md-3">
							<label>Semester:</label>
							<select name="semester" class="form-control" required>
							<?php
								$query="SELECT DISTINCT semester FROM semester ORDER BY semester_id";
								if($result=mysqli_query($connection,$query)){
									if(mysqli_num_rows($result) > 0){
										while ($row = mysqli_fetch_array($result)){
											echo "<option value='".$row['semester']."'>".$row['semester']."</option>";
										}
									}
								}
							?>  
							</select>
						</div>
						<div class="col-md-3">
							<label>Year:</label>
							<input type="text" name="year" class="form-control" placeholder="Ex: 2026" value="<?php echo date('Y'); ?>" required>
						</div>
						<div class="col-md-3">
							<label>Department:</label>
							<select name="dept_name" class="form-control" required>
							<?php
								$sql="SELECT DISTINCT dept FROM dept";
								if($result=mysqli_query($connection,$sql)){
									if(mysqli_num_rows($result) > 0){
										while ($row = mysqli_fetch_array($result)){
											echo "<option value='".$row['dept']."'>".$row['dept']."</option>";
										}
									}
								}
							?>  
							</select>
						</div>
						<div class="col-md-3"><br>
							<input type="submit" name="search" class="btn btn-primary btn-block" value="Select / Filter">
						</div>
					</div>
				</form>
			</div>
		</div>

		<!-- Offer New Course Form & Table -->
		<form method="POST" name='f2'>
			<div class="table-responsive" style="border: none;">
				<table id="tbl2" class="table table-bordered table-striped" width="100%">
					<thead>
						<tr>
							<th>Course Code</th>
							<th>Total Section</th>
							<th colspan="2" style="text-align: center;">Action</th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td>
								<select name="offered_course_code" class="form-control">
									<option value="">-- Select Course --</option>
									<?php	 
										$sql = "SELECT DISTINCT course_code FROM course";
										if($select = mysqli_query($connection,$sql)){
											if(mysqli_num_rows($select) > 0) {
												while ($row = mysqli_fetch_array($select)) {
													echo "<option value='".$row['course_code']."'>".$row['course_code']."</option>";
												}
											}
										}
									?>
								</select>
							</td>
							<td><input type="text" name="sec_no" class="form-control" placeholder="Ex: 2"></td>
							<td colspan="2" style="text-align: center;">
								<button type="submit" name="insert_row" class="btn btn-success"><i class="fa fa-plus-circle"></i> Offer Course</button>
							</td>
						</tr>
					
						<?php 
							$sql_list = "SELECT a.course_code as course_code, b.tot_sec as total_section, b.offered_course_id, b.year
										 FROM course a 
										 INNER JOIN offered_course b ON a.course_id=b.course_id 
										 INNER JOIN semester c ON b.semester_id=c.semester_id 
										 WHERE c.semester='$s' AND b.year='$y'";

							if($result2 = mysqli_query($connection, $sql_list)){
								if(mysqli_num_rows($result2) > 0){
									while($row = mysqli_fetch_array($result2)){
										echo "<tr>";
										echo "<td><strong>".$row["course_code"]."</strong></td>";
										echo "<td>".$row["total_section"]."</td>";		
						?>
							<td style="text-align: center;">
								<button type="submit" name="edit_row" class="btn btn-warning btn-sm" value="<?php echo $row['offered_course_id']; ?>"><i class="fa fa-edit"></i></button>
							</td>
							<td style="text-align: center;">
								<button type="submit" name="delete_row" class="btn btn-danger btn-sm" value="<?php echo $row['offered_course_id']; ?>" onclick="return confirm('Are you sure to delete?')"><i class="fa fa-trash"></i></button>
							</td>
						</tr>
						<?php
									}
								}
							}
						?>
					</tbody>
				</table>
			</div>
		</form>
	   </div>

	</div>
  </div>
</body>
</html>